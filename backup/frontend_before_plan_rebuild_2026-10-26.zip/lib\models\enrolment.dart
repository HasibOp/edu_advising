enum EnrolmentStatus { enrolled, dropped }

class Enrolment {
  const Enrolment({
    required this.id,
    required this.studentId,
    required this.offeringId,
    required this.status,
    required this.createdAt,
  });

  final String id;
  final String studentId;
  final String offeringId;
  final EnrolmentStatus status;
  final DateTime createdAt;

  bool get isActive => status == EnrolmentStatus.enrolled;

  Enrolment copyWith({EnrolmentStatus? status}) {
    return Enrolment(
      id: id,
      studentId: studentId,
      offeringId: offeringId,
      status: status ?? this.status,
      createdAt: createdAt,
    );
  }

  factory Enrolment.fromJson(Map<String, dynamic> json) {
    return Enrolment(
      id: json['id'] as String,
      studentId: json['studentId'] as String,
      offeringId: json['offeringId'] as String,
      status: EnrolmentStatus.values.byName(json['status'] as String),
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'studentId': studentId,
        'offeringId': offeringId,
        'status': status.name,
        'createdAt': createdAt.toIso8601String(),
      };
}
