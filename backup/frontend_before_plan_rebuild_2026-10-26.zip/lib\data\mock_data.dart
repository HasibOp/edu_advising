import '../models/advising_windows.dart';
import '../models/enrolment.dart';
import '../models/exam_schedule.dart';
import '../models/extra_request.dart';
import '../models/offering.dart';
import '../models/schedule.dart';
import '../models/user.dart';

/// Hardcoded seed data used by [MockApiService] until the backend exists.
class MockData {
  MockData._();

  static const String demoStudentId = '2021-1-60-015';

  static const List<User> users = [
    User(
      id: 'u-admin',
      role: UserRole.admin,
      studentId: 'admin',
      name: 'Registrar Office',
      clearanceStatus: ClearanceStatus.cleared,
    ),
    User(
      id: 'u-instructor',
      role: UserRole.instructor,
      studentId: 'instructor',
      name: 'Dr. Ahmed Rahman',
      clearanceStatus: ClearanceStatus.cleared,
    ),
    User(
      id: 'u-1',
      role: UserRole.student,
      studentId: demoStudentId,
      name: 'Ayaan Karim',
      semester: 10,
      clearanceStatus: ClearanceStatus.cleared,
    ),
    User(
      id: 'u-2',
      role: UserRole.student,
      studentId: '2021-1-60-022',
      name: 'Nadia Sultana',
      semester: 10,
      clearanceStatus: ClearanceStatus.cleared,
    ),
    User(
      id: 'u-3',
      role: UserRole.student,
      studentId: '2021-2-60-008',
      name: 'Rafi Chowdhury',
      semester: 9,
      clearanceStatus: ClearanceStatus.notCleared,
    ),
    User(
      id: 'u-4',
      role: UserRole.student,
      studentId: '2020-3-60-041',
      name: 'Sumaiya Akter',
      semester: 11,
      clearanceStatus: ClearanceStatus.cleared,
    ),
    User(
      id: 'u-5',
      role: UserRole.student,
      studentId: '2021-3-60-030',
      name: 'Fahim Reza',
      semester: 9,
      clearanceStatus: ClearanceStatus.notCleared,
    ),
  ];

  static List<ClassSchedule> _satMon(String start, String end, String room) => [
        ClassSchedule(day: Weekday.sat, startTime: start, endTime: end, room: room),
        ClassSchedule(day: Weekday.mon, startTime: start, endTime: end, room: room),
      ];

  static List<ClassSchedule> _sunTue(String start, String end, String room) => [
        ClassSchedule(day: Weekday.sun, startTime: start, endTime: end, room: room),
        ClassSchedule(day: Weekday.tue, startTime: start, endTime: end, room: room),
      ];

  static final List<Offering> offerings = [
    // Semester 9
    Offering(
      id: 'off-325-a', courseCode: 'CSE 325', courseTitle: 'Operating Systems',
      section: 'A', semester: 9, credits: 3, capacity: 40, seatsTaken: 40,
      facultyId: 'F002', facultyName: 'Dr. Nusrat Jahan',
      schedule: _satMon('08:30', '09:50', 'AB1-301'),
    ),
    Offering(
      id: 'off-325-b', courseCode: 'CSE 325', courseTitle: 'Operating Systems',
      section: 'B', semester: 9, credits: 3, capacity: 40, seatsTaken: 22,
      facultyId: 'F002', facultyName: 'Dr. Nusrat Jahan',
      schedule: _sunTue('10:00', '11:20', 'AB1-302'),
    ),
    Offering(
      id: 'off-360-a', courseCode: 'CSE 360', courseTitle: 'Computer Architecture',
      section: 'A', semester: 9, credits: 3, capacity: 35, seatsTaken: 30,
      facultyId: 'F003', facultyName: 'Mr. Tanvir Hasan',
      schedule: _satMon('11:30', '12:50', 'AB2-204'),
    ),
    Offering(
      id: 'off-360-b', courseCode: 'CSE 360', courseTitle: 'Computer Architecture',
      section: 'B', semester: 9, credits: 3, capacity: 35, seatsTaken: 35,
      facultyId: 'F003', facultyName: 'Mr. Tanvir Hasan',
      schedule: _sunTue('13:00', '14:20', 'AB2-204'),
    ),
    Offering(
      id: 'off-366-a', courseCode: 'CSE 366', courseTitle: 'Artificial Intelligence',
      section: 'A', semester: 9, credits: 3, capacity: 40, seatsTaken: 18,
      facultyId: 'F001', facultyName: 'Dr. Ahmed Rahman',
      schedule: _sunTue('08:30', '09:50', 'AB3-110'),
    ),

    // Semester 10
    Offering(
      id: 'off-300-a', courseCode: 'CSE 300', courseTitle: 'Technical Writing & Seminar',
      section: 'A', semester: 10, credits: 1, capacity: 30, seatsTaken: 10,
      facultyId: 'F004', facultyName: 'Ms. Farzana Akter',
      schedule: _satMon('08:30', '09:50', 'AB1-105'),
    ),
    Offering(
      id: 'off-421-a', courseCode: 'CSE 421', courseTitle: 'Machine Learning',
      section: 'A', semester: 10, credits: 3, capacity: 40, seatsTaken: 12,
      facultyId: 'F001', facultyName: 'Dr. Ahmed Rahman',
      schedule: _satMon('10:00', '11:20', 'AB3-201'),
    ),
    Offering(
      id: 'off-421-b', courseCode: 'CSE 421', courseTitle: 'Machine Learning',
      section: 'B', semester: 10, credits: 3, capacity: 40, seatsTaken: 37,
      facultyId: 'F001', facultyName: 'Dr. Ahmed Rahman',
      schedule: _sunTue('11:30', '12:50', 'AB3-201'),
    ),
    Offering(
      id: 'off-412-a', courseCode: 'CSE 412', courseTitle: 'Software Engineering',
      section: 'A', semester: 10, credits: 3, capacity: 40, seatsTaken: 40,
      facultyId: 'F005', facultyName: 'Dr. Kamal Uddin',
      schedule: _satMon('13:00', '14:20', 'AB2-310'),
    ),
    Offering(
      id: 'off-412-b', courseCode: 'CSE 412', courseTitle: 'Software Engineering',
      section: 'B', semester: 10, credits: 3, capacity: 40, seatsTaken: 25,
      facultyId: 'F005', facultyName: 'Dr. Kamal Uddin',
      schedule: _sunTue('14:30', '15:50', 'AB2-310'),
    ),
    Offering(
      id: 'off-430-a', courseCode: 'CSE 430', courseTitle: 'Mobile Application Development',
      section: 'A', semester: 10, credits: 3, capacity: 35, seatsTaken: 20,
      facultyId: 'F003', facultyName: 'Mr. Tanvir Hasan',
      schedule: _sunTue('08:30', '09:50', 'Lab-4'),
    ),
    Offering(
      id: 'off-430-b', courseCode: 'CSE 430', courseTitle: 'Mobile Application Development',
      section: 'B', semester: 10, credits: 3, capacity: 35, seatsTaken: 31,
      facultyId: 'F003', facultyName: 'Mr. Tanvir Hasan',
      schedule: _satMon('14:30', '15:50', 'Lab-4'),
    ),

    // Semester 11
    Offering(
      id: 'off-400-a', courseCode: 'CSE 400', courseTitle: 'Capstone Project I',
      section: 'A', semester: 11, credits: 3, capacity: 30, seatsTaken: 8,
      facultyId: 'F005', facultyName: 'Dr. Kamal Uddin',
      schedule: _satMon('11:30', '12:50', 'AB1-401'),
    ),
    Offering(
      id: 'off-487-a', courseCode: 'CSE 487', courseTitle: 'Cyber Security',
      section: 'A', semester: 11, credits: 3, capacity: 30, seatsTaken: 26,
      facultyId: 'F004', facultyName: 'Ms. Farzana Akter',
      schedule: _sunTue('10:00', '11:20', 'AB3-305'),
    ),
    Offering(
      id: 'off-487-b', courseCode: 'CSE 487', courseTitle: 'Cyber Security',
      section: 'B', semester: 11, credits: 3, capacity: 30, seatsTaken: 30,
      facultyId: 'F004', facultyName: 'Ms. Farzana Akter',
      schedule: _sunTue('13:00', '14:20', 'AB3-305'),
    ),
    Offering(
      id: 'off-495-a', courseCode: 'CSE 495', courseTitle: 'Natural Language Processing',
      section: 'A', semester: 11, credits: 3, capacity: 35, seatsTaken: 34,
      facultyId: 'F001', facultyName: 'Dr. Ahmed Rahman',
      schedule: _satMon('13:00', '14:20', 'AB3-202'),
    ),
  ];

  static final List<Enrolment> enrolments = [
    Enrolment(
      id: 'enr-1', studentId: '2021-1-60-022', offeringId: 'off-421-b',
      status: EnrolmentStatus.enrolled, createdAt: DateTime(2026, 10, 20, 10, 15),
    ),
    Enrolment(
      id: 'enr-2', studentId: '2021-1-60-022', offeringId: 'off-412-b',
      status: EnrolmentStatus.enrolled, createdAt: DateTime(2026, 10, 20, 10, 15),
    ),
    Enrolment(
      id: 'enr-3', studentId: '2021-1-60-022', offeringId: 'off-300-a',
      status: EnrolmentStatus.enrolled, createdAt: DateTime(2026, 10, 20, 10, 16),
    ),
    Enrolment(
      id: 'enr-4', studentId: '2020-3-60-041', offeringId: 'off-400-a',
      status: EnrolmentStatus.enrolled, createdAt: DateTime(2026, 10, 21, 9, 5),
    ),
  ];

  static final List<ExtraRequest> extraRequests = [
    ExtraRequest(
      id: 'req-1', studentId: demoStudentId, courseCode: 'CSE 325',
      reason: 'I missed Operating Systems last semester and need it as a prerequisite for CSE 430.',
      status: RequestStatus.pending, createdAt: DateTime(2026, 10, 22, 14, 30),
    ),
    ExtraRequest(
      id: 'req-2', studentId: '2021-1-60-022', courseCode: 'CSE 495',
      reason: 'I want to take NLP as an elective to support my thesis on Bangla text classification.',
      status: RequestStatus.pending, createdAt: DateTime(2026, 10, 23, 11, 0),
    ),
  ];

  /// Midterm week: Sat 14 Nov - Tue 17 Nov 2026.
  static final List<ExamSchedule> exams = [
    ExamSchedule(courseCode: 'CSE 300', type: 'Midterm', date: DateTime(2026, 11, 14), startTime: '09:00', endTime: '10:30', room: 'AB1-105'),
    ExamSchedule(courseCode: 'CSE 325', type: 'Midterm', date: DateTime(2026, 11, 14), startTime: '12:00', endTime: '13:30', room: 'AB1-301'),
    ExamSchedule(courseCode: 'CSE 487', type: 'Midterm', date: DateTime(2026, 11, 14), startTime: '15:00', endTime: '16:30', room: 'AB3-305'),
    ExamSchedule(courseCode: 'CSE 360', type: 'Midterm', date: DateTime(2026, 11, 15), startTime: '09:00', endTime: '10:30', room: 'AB2-204'),
    ExamSchedule(courseCode: 'CSE 421', type: 'Midterm', date: DateTime(2026, 11, 15), startTime: '12:00', endTime: '13:30', room: 'AB3-201'),
    ExamSchedule(courseCode: 'CSE 412', type: 'Midterm', date: DateTime(2026, 11, 16), startTime: '09:00', endTime: '10:30', room: 'AB2-310'),
    ExamSchedule(courseCode: 'CSE 495', type: 'Midterm', date: DateTime(2026, 11, 16), startTime: '12:00', endTime: '13:30', room: 'AB3-202'),
    ExamSchedule(courseCode: 'CSE 366', type: 'Midterm', date: DateTime(2026, 11, 16), startTime: '15:00', endTime: '16:30', room: 'AB3-110'),
    ExamSchedule(courseCode: 'CSE 400', type: 'Midterm', date: DateTime(2026, 11, 17), startTime: '09:00', endTime: '10:30', room: 'AB1-401'),
    ExamSchedule(courseCode: 'CSE 430', type: 'Midterm', date: DateTime(2026, 11, 17), startTime: '15:00', endTime: '16:30', room: 'Lab-4'),
  ];

  static const AdvisingWindows windows =
      AdvisingWindows(regularAdvising: true, extraCourse: true);
}
