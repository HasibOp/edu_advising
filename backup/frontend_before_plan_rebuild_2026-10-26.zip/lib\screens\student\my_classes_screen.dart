import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/offering.dart';
import '../../providers/advising_provider.dart';
import '../../utils/app_theme.dart';
import '../../utils/formatters.dart';
import '../../utils/pdf_generator.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/logout_button.dart';
import '../../widgets/state_views.dart';
import 'student_async_body.dart';

class MyClassesScreen extends StatefulWidget {
  const MyClassesScreen({super.key, required this.onStartAdvising});

  final VoidCallback onStartAdvising;

  @override
  State<MyClassesScreen> createState() => _MyClassesScreenState();
}

class _MyClassesScreenState extends State<MyClassesScreen> {
  bool _exporting = false;

  Future<void> _downloadPdf(AdvisingProvider advising) async {
    setState(() => _exporting = true);
    try {
      final student = advising.student!;
      final bytes = await PdfGenerator.classList(
        student: student,
        offerings: advising.enrolledOfferings,
      );
      await PdfGenerator.share(bytes, 'my_classes_${student.studentId}.pdf');
    } catch (e) {
      if (mounted) showAppSnackBar(context, 'Could not create PDF: $e', isError: true);
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Classes'),
        actions: const [LogoutButton()],
      ),
      body: StudentAsyncBody(builder: (context) {
        final advising = context.watch<AdvisingProvider>();
        final classes = advising.enrolledOfferings;

        if (classes.isEmpty) {
          return EmptyState(
            icon: Icons.event_busy_rounded,
            title: 'No classes yet',
            message: 'Pick your sections in Advising and confirm them.',
            action: CustomButton(
              label: 'Go to Advising',
              onPressed: widget.onStartAdvising,
            ),
          );
        }

        return Column(
          children: [
            Expanded(
              child: RefreshIndicator(
                onRefresh: advising.refresh,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _SummaryCard(
                      courses: classes.length,
                      credits: advising.enrolledCredits,
                    ),
                    const SizedBox(height: 12),
                    for (final o in classes) _ClassCard(offering: o),
                  ],
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: AppColors.border)),
              ),
              child: CustomButton(
                label: 'Download PDF',
                icon: Icons.picture_as_pdf_outlined,
                expand: true,
                isLoading: _exporting,
                onPressed: () => _downloadPdf(advising),
              ),
            ),
          ],
        );
      }),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.courses, required this.credits});

  final int courses;
  final int credits;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.primary,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          _Stat(value: '$courses', label: 'Courses'),
          Container(width: 1, height: 36, color: Colors.white24),
          _Stat(value: '$credits', label: 'Credits'),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
                color: Colors.white, fontSize: 24, fontWeight: FontWeight.w700),
          ),
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      ),
    );
  }
}

class _ClassCard extends StatelessWidget {
  const _ClassCard({required this.offering});

  final Offering offering;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: AppColors.border),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 52,
              height: 52,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.blockColorFor(offering.courseCode),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                offering.section,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primaryDark,
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    offering.displayName,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5),
                  ),
                  Text(
                    offering.courseTitle,
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    Formatters.schedule(offering),
                    style: const TextStyle(fontSize: 12.5),
                  ),
                  Text(
                    'Room ${Formatters.rooms(offering)}  •  ${offering.facultyName}',
                    style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                  ),
                ],
              ),
            ),
            Text(
              '${offering.credits} cr',
              style: const TextStyle(
                  fontWeight: FontWeight.w600, color: AppColors.primary),
            ),
          ],
        ),
      ),
    );
  }
}
