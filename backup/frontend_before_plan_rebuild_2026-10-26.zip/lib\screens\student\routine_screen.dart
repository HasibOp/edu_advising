import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/advising_provider.dart';
import '../../utils/app_theme.dart';
import '../../utils/formatters.dart';
import '../../utils/pdf_generator.dart';
import '../../utils/routine_config.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/logout_button.dart';
import '../../widgets/routine_grid.dart';
import '../../widgets/state_views.dart';
import 'student_async_body.dart';

class RoutineScreen extends StatelessWidget {
  const RoutineScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Routine'),
          actions: const [LogoutButton()],
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            indicatorWeight: 3,
            dividerColor: Colors.transparent,
            tabs: [Tab(text: 'Class'), Tab(text: 'Exam')],
          ),
        ),
        body: StudentAsyncBody(
          builder: (_) => const TabBarView(
            children: [_ClassRoutineTab(), _ExamRoutineTab()],
          ),
        ),
      ),
    );
  }
}

class _ClassRoutineTab extends StatelessWidget {
  const _ClassRoutineTab();

  @override
  Widget build(BuildContext context) {
    final advising = context.watch<AdvisingProvider>();
    final classes = advising.enrolledOfferings;

    if (classes.isEmpty) {
      return const EmptyState(
        icon: Icons.calendar_today_outlined,
        title: 'Your class routine is empty',
        message: 'Confirm advising to see your weekly classes here.',
      );
    }

    final blocks = [
      for (final o in classes)
        for (final s in o.schedule)
          RoutineBlock(
            day: s.day,
            startTime: s.startTime,
            title: o.courseCode,
            subtitle: '${o.section}  ${s.room}',
            color: AppColors.blockColorFor(o.courseCode),
          ),
    ];

    return _RoutineTabBody(
      grid: RoutineGrid(slots: RoutineConfig.classSlots, blocks: blocks),
      legend: [
        for (final o in classes)
          _LegendRow(
            color: AppColors.blockColorFor(o.courseCode),
            title: '${o.displayName}  •  ${o.courseTitle}',
            subtitle: Formatters.schedule(o),
          ),
      ],
      exportPdf: () => PdfGenerator.routine(
        title: 'Class Routine',
        student: advising.student!,
        slots: RoutineConfig.classSlots,
        cells: [
          for (final o in classes)
            for (final s in o.schedule)
              PdfRoutineCell(
                day: s.day,
                startTime: s.startTime,
                lines: [o.courseCode, 'Sec ${o.section}', s.room],
              ),
        ],
      ),
      filename: 'class_routine_${advising.student!.studentId}.pdf',
    );
  }
}

class _ExamRoutineTab extends StatelessWidget {
  const _ExamRoutineTab();

  @override
  Widget build(BuildContext context) {
    final advising = context.watch<AdvisingProvider>();
    final exams = advising.myExams;

    if (exams.isEmpty) {
      return const EmptyState(
        icon: Icons.edit_calendar_outlined,
        title: 'No exams scheduled',
        message: 'Exams for your enrolled courses will show up here.',
      );
    }

    return _RoutineTabBody(
      grid: RoutineGrid(
        slots: RoutineConfig.examSlots,
        blocks: [
          for (final e in exams)
            RoutineBlock(
              day: e.day,
              startTime: e.startTime,
              title: e.courseCode,
              subtitle: e.room,
              color: AppColors.blockColorFor(e.courseCode),
            ),
        ],
      ),
      legend: [
        for (final e in exams)
          _LegendRow(
            color: AppColors.blockColorFor(e.courseCode),
            title: '${e.courseCode}  •  ${e.type}',
            subtitle:
                '${Formatters.dayDate(e.date)}  •  ${Formatters.timeRange(e.startTime, e.endTime)}  •  ${e.room}',
          ),
      ],
      exportPdf: () => PdfGenerator.routine(
        title: 'Exam Routine',
        student: advising.student!,
        slots: RoutineConfig.examSlots,
        cells: [
          for (final e in exams)
            PdfRoutineCell(
              day: e.day,
              startTime: e.startTime,
              lines: [e.courseCode, e.type, Formatters.date(e.date), e.room],
            ),
        ],
      ),
      filename: 'exam_routine_${advising.student!.studentId}.pdf',
    );
  }
}

/// Grid, legend and a "Download PDF" button, shared by both tabs.
class _RoutineTabBody extends StatefulWidget {
  const _RoutineTabBody({
    required this.grid,
    required this.legend,
    required this.exportPdf,
    required this.filename,
  });

  final Widget grid;
  final List<Widget> legend;
  final Future<Uint8List> Function() exportPdf;
  final String filename;

  @override
  State<_RoutineTabBody> createState() => _RoutineTabBodyState();
}

class _RoutineTabBodyState extends State<_RoutineTabBody> {
  bool _exporting = false;

  Future<void> _download() async {
    setState(() => _exporting = true);
    try {
      final bytes = await widget.exportPdf();
      await PdfGenerator.share(bytes, widget.filename);
    } catch (e) {
      if (mounted) showAppSnackBar(context, 'Could not create PDF: $e', isError: true);
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        widget.grid,
        const SectionHeader('Details'),
        ...widget.legend,
        const SizedBox(height: 16),
        CustomButton(
          label: 'Download PDF',
          icon: Icons.picture_as_pdf_outlined,
          expand: true,
          isLoading: _exporting,
          onPressed: _download,
        ),
      ],
    );
  }
}

class _LegendRow extends StatelessWidget {
  const _LegendRow({required this.color, required this.title, required this.subtitle});

  final Color color;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 14,
            height: 14,
            margin: const EdgeInsets.only(top: 3),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: AppColors.border),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                Text(subtitle,
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
