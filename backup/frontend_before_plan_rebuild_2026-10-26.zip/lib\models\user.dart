enum UserRole { student, instructor, admin }

enum ClearanceStatus {
  cleared('Cleared'),
  notCleared('Not cleared');

  const ClearanceStatus(this.label);
  final String label;
}

class User {
  const User({
    required this.id,
    required this.role,
    required this.studentId,
    required this.name,
    this.semester = 0,
    this.clearanceStatus = ClearanceStatus.notCleared,
  });

  final String id;
  final UserRole role;

  /// Login ID. For staff accounts this is their username.
  final String studentId;
  final String name;

  /// Current semester of a student; 0 for staff.
  final int semester;
  final ClearanceStatus clearanceStatus;

  bool get isCleared => clearanceStatus == ClearanceStatus.cleared;

  User copyWith({String? name, int? semester, ClearanceStatus? clearanceStatus}) {
    return User(
      id: id,
      role: role,
      studentId: studentId,
      name: name ?? this.name,
      semester: semester ?? this.semester,
      clearanceStatus: clearanceStatus ?? this.clearanceStatus,
    );
  }

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as String,
      role: UserRole.values.byName(json['role'] as String),
      studentId: json['studentId'] as String,
      name: json['name'] as String,
      semester: json['semester'] as int? ?? 0,
      clearanceStatus:
          ClearanceStatus.values.byName(json['clearanceStatus'] as String),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'role': role.name,
        'studentId': studentId,
        'name': name,
        'semester': semester,
        'clearanceStatus': clearanceStatus.name,
      };
}
