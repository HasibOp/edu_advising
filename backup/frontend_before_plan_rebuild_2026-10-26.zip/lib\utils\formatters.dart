import 'package:intl/intl.dart';

import '../models/offering.dart';

class Formatters {
  Formatters._();

  static final DateFormat _hhmm = DateFormat('HH:mm');
  static final DateFormat _time = DateFormat('h:mm a');
  static final DateFormat _date = DateFormat('d MMM yyyy');
  static final DateFormat _dayDate = DateFormat('EEE, d MMM');
  static final DateFormat _dateTime = DateFormat('d MMM yyyy, h:mm a');

  /// "08:30" -> "8:30 AM"
  static String time(String hhmm) => _time.format(_hhmm.parse(hhmm));

  /// "08:30", "09:50" -> "8:30 AM - 9:50 AM"
  static String timeRange(String start, String end) =>
      '${time(start)} - ${time(end)}';

  static String date(DateTime d) => _date.format(d);
  static String dayDate(DateTime d) => _dayDate.format(d);
  static String dateTime(DateTime d) => _dateTime.format(d);

  /// Groups meetings that share a time, e.g. "Sat, Mon  8:30 AM - 9:50 AM".
  static String schedule(Offering offering) {
    final byTime = <String, List<String>>{};
    for (final s in offering.schedule) {
      byTime
          .putIfAbsent(timeRange(s.startTime, s.endTime), () => [])
          .add(s.day.short);
    }
    if (byTime.isEmpty) return 'TBA';
    return byTime.entries
        .map((e) => '${e.value.join(', ')}  ${e.key}')
        .join(' | ');
  }

  static String rooms(Offering offering) {
    final rooms = offering.schedule.map((s) => s.room).toSet();
    return rooms.isEmpty ? 'TBA' : rooms.join(', ');
  }
}
