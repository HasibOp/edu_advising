/// Which advising periods the admin currently has open.
class AdvisingWindows {
  const AdvisingWindows({
    this.regularAdvising = false,
    this.extraCourse = false,
  });

  final bool regularAdvising;
  final bool extraCourse;

  AdvisingWindows copyWith({bool? regularAdvising, bool? extraCourse}) {
    return AdvisingWindows(
      regularAdvising: regularAdvising ?? this.regularAdvising,
      extraCourse: extraCourse ?? this.extraCourse,
    );
  }

  factory AdvisingWindows.fromJson(Map<String, dynamic> json) {
    return AdvisingWindows(
      regularAdvising: json['regularAdvising'] as bool? ?? false,
      extraCourse: json['extraCourse'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'regularAdvising': regularAdvising,
        'extraCourse': extraCourse,
      };
}
