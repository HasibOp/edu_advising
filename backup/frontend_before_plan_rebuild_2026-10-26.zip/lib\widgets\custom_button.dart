import 'package:flutter/material.dart';

import '../utils/app_theme.dart';

enum ButtonVariant { primary, success, danger, warning, outline }

/// App-wide filled button with colour variants and a loading state.
class CustomButton extends StatelessWidget {
  const CustomButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.variant = ButtonVariant.primary,
    this.icon,
    this.isLoading = false,
    this.expand = false,
    this.compact = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final ButtonVariant variant;
  final IconData? icon;
  final bool isLoading;

  /// Stretch to the full available width.
  final bool expand;

  /// Smaller padding for buttons inside cards (DROP, GIVE, ...).
  final bool compact;

  (Color, Color) get _colors {
    switch (variant) {
      case ButtonVariant.primary:
        return (AppColors.primary, Colors.white);
      case ButtonVariant.success:
        return (AppColors.success, Colors.white);
      case ButtonVariant.danger:
        return (AppColors.danger, Colors.white);
      case ButtonVariant.warning:
        return (AppColors.warning, AppColors.onWarning);
      case ButtonVariant.outline:
        return (Colors.transparent, AppColors.primary);
    }
  }

  @override
  Widget build(BuildContext context) {
    final (background, foreground) = _colors;
    final style = FilledButton.styleFrom(
      backgroundColor: background,
      foregroundColor: foreground,
      disabledBackgroundColor: variant == ButtonVariant.outline
          ? Colors.transparent
          : background.withAlpha(90),
      disabledForegroundColor: foreground.withAlpha(170),
      minimumSize: compact ? const Size(64, 36) : const Size(88, 50),
      padding: compact
          ? const EdgeInsets.symmetric(horizontal: 14)
          : const EdgeInsets.symmetric(horizontal: 22),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      side: variant == ButtonVariant.outline
          ? const BorderSide(color: AppColors.primary, width: 1.4)
          : null,
      textStyle: TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: compact ? 12.5 : 15,
        letterSpacing: compact ? 0.4 : 0.1,
      ),
    );

    final child = isLoading
        ? SizedBox(
            width: compact ? 16 : 22,
            height: compact ? 16 : 22,
            child: CircularProgressIndicator(strokeWidth: 2.4, color: foreground),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, size: compact ? 16 : 20),
                const SizedBox(width: 8),
              ],
              Flexible(child: Text(label, overflow: TextOverflow.ellipsis)),
            ],
          );

    final button = FilledButton(
      onPressed: isLoading ? null : onPressed,
      style: style,
      child: child,
    );
    return expand ? SizedBox(width: double.infinity, child: button) : button;
  }
}
