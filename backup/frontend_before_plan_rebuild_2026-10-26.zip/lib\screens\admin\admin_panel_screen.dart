import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/user.dart';
import '../../providers/admin_provider.dart';
import '../../utils/app_theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/logout_button.dart';
import '../../widgets/state_views.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  String _filter = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
        (_) => context.read<AdminProvider>().load());
  }

  Future<void> _toggleWindow(
      Future<String?> Function(bool) save, bool open, String name) async {
    final error = await save(open);
    if (!mounted) return;
    showAppSnackBar(
      context,
      error ?? '$name ${open ? 'opened' : 'closed'}.',
      isError: error != null,
    );
  }

  Future<void> _setClearance(
      AdminProvider admin, User student, ClearanceStatus status) async {
    final error = await admin.setClearance(student, status);
    if (!mounted) return;
    showAppSnackBar(
      context,
      error ??
          (status == ClearanceStatus.cleared
              ? 'Clearance given to ${student.studentId}.'
              : 'Clearance revoked for ${student.studentId}.'),
      isError: error != null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final admin = context.watch<AdminProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        actions: const [LogoutButton()],
      ),
      body: _buildBody(admin),
    );
  }

  Widget _buildBody(AdminProvider admin) {
    if (admin.isLoading && admin.students.isEmpty) return const LoadingView();
    if (admin.loadError != null && admin.students.isEmpty) {
      return EmptyState(
        icon: Icons.cloud_off_rounded,
        title: 'Could not load admin data',
        message: admin.loadError,
        action: CustomButton(label: 'Try again', onPressed: admin.load),
      );
    }

    final q = _filter.trim().toLowerCase();
    final students = admin.students
        .where((s) =>
            q.isEmpty ||
            s.studentId.toLowerCase().contains(q) ||
            s.name.toLowerCase().contains(q))
        .toList();

    return RefreshIndicator(
      onRefresh: admin.load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SectionHeader('Windows'),
          Card(
            elevation: 0,
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
              side: const BorderSide(color: AppColors.border),
            ),
            child: Column(
              children: [
                _WindowSwitch(
                  title: 'Regular advising',
                  icon: Icons.fact_check_outlined,
                  value: admin.windows.regularAdvising,
                  onChanged: (v) =>
                      _toggleWindow(admin.setRegularAdvising, v, 'Regular advising'),
                ),
                const Divider(height: 1, indent: 16, endIndent: 16),
                _WindowSwitch(
                  title: 'Extra course',
                  icon: Icons.add_task_outlined,
                  value: admin.windows.extraCourse,
                  onChanged: (v) =>
                      _toggleWindow(admin.setExtraCourse, v, 'Extra course window'),
                ),
              ],
            ),
          ),
          SectionHeader(
            'Clearance',
            trailing: Text(
              '${admin.clearedCount}/${admin.students.length} cleared',
              style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
            ),
          ),
          TextField(
            onChanged: (v) => setState(() => _filter = v),
            decoration: const InputDecoration(
              hintText: 'Filter by student ID or name',
              prefixIcon: Icon(Icons.filter_list_rounded),
            ),
          ),
          const SizedBox(height: 12),
          if (students.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('No students match.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.textMuted)),
            ),
          for (final s in students)
            _ClearanceRow(
              student: s,
              busy: admin.isBusy(s.studentId),
              onGive: () => _setClearance(admin, s, ClearanceStatus.cleared),
              onRevoke: () => _setClearance(admin, s, ClearanceStatus.notCleared),
            ),
        ],
      ),
    );
  }
}

class _WindowSwitch extends StatelessWidget {
  const _WindowSwitch({
    required this.title,
    required this.icon,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final IconData icon;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      secondary: Icon(icon, color: AppColors.primary),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(
        value ? 'ON' : 'OFF',
        style: TextStyle(
          color: value ? AppColors.success : AppColors.danger,
          fontWeight: FontWeight.w700,
        ),
      ),
      value: value,
      activeThumbColor: AppColors.primary,
      onChanged: onChanged,
    );
  }
}

class _ClearanceRow extends StatelessWidget {
  const _ClearanceRow({
    required this.student,
    required this.busy,
    required this.onGive,
    required this.onRevoke,
  });

  final User student;
  final bool busy;
  final VoidCallback onGive;
  final VoidCallback onRevoke;

  @override
  Widget build(BuildContext context) {
    final cleared = student.isCleared;
    final statusColor = cleared ? AppColors.success : AppColors.danger;

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: AppColors.border),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(student.studentId,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(
                    '${student.name}  •  Sem ${student.semester}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(cleared ? Icons.check_circle : Icons.cancel,
                          size: 15, color: statusColor),
                      const SizedBox(width: 4),
                      Text(
                        student.clearanceStatus.label,
                        style: TextStyle(
                          color: statusColor,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if (busy)
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              )
            else ...[
              CustomButton(
                label: 'GIVE',
                variant: ButtonVariant.success,
                compact: true,
                onPressed: cleared ? null : onGive,
              ),
              const SizedBox(width: 6),
              CustomButton(
                label: 'REVOKE',
                variant: ButtonVariant.danger,
                compact: true,
                onPressed: cleared ? onRevoke : null,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
