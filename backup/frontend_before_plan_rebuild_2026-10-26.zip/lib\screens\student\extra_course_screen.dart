import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/extra_request.dart';
import '../../providers/advising_provider.dart';
import '../../utils/app_theme.dart';
import '../../utils/formatters.dart';
import '../../utils/validators.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/logout_button.dart';
import '../../widgets/notice_banner.dart';
import '../../widgets/state_views.dart';
import '../../widgets/status_badge.dart';
import 'student_async_body.dart';

class ExtraCourseScreen extends StatefulWidget {
  const ExtraCourseScreen({super.key});

  @override
  State<ExtraCourseScreen> createState() => _ExtraCourseScreenState();
}

class _ExtraCourseScreenState extends State<ExtraCourseScreen> {
  final _formKey = GlobalKey<FormState>();
  final _codeController = TextEditingController();
  final _reasonController = TextEditingController();
  final Set<String> _withdrawing = {};

  @override
  void dispose() {
    _codeController.dispose();
    _reasonController.dispose();
    super.dispose();
  }

  Future<void> _send(AdvisingProvider advising) async {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    final error = await advising.sendExtraRequest(
        _codeController.text, _reasonController.text);
    if (!mounted) return;
    if (error != null) {
      showAppSnackBar(context, error, isError: true);
      return;
    }
    _formKey.currentState!.reset();
    _codeController.clear();
    _reasonController.clear();
    showAppSnackBar(context, 'Request sent to your advisor.');
  }

  Future<void> _withdraw(AdvisingProvider advising, ExtraRequest request) async {
    final ok = await confirmDialog(
      context,
      title: 'Withdraw request?',
      message: 'Your request for ${request.courseCode} will be cancelled.',
      confirmLabel: 'Withdraw',
      destructive: true,
    );
    if (!ok || !mounted) return;
    setState(() => _withdrawing.add(request.id));
    final error = await advising.withdrawRequest(request);
    if (!mounted) return;
    setState(() => _withdrawing.remove(request.id));
    showAppSnackBar(context, error ?? 'Request withdrawn.', isError: error != null);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Extra Course'),
        actions: const [LogoutButton()],
      ),
      body: StudentAsyncBody(builder: (context) {
        final advising = context.watch<AdvisingProvider>();
        final windowOpen = advising.windows.extraCourse;
        final requests = advising.extraRequests;

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (!windowOpen) ...[
              const WarningBanner(
                title: 'Extra course window closed',
                message: 'You can send new requests when the admin opens it.',
              ),
              const SizedBox(height: 12),
            ],
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: const BorderSide(color: AppColors.border),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Request an extra course',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Ask your advisor for a course outside your regular plan.',
                        style: TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _codeController,
                        enabled: windowOpen,
                        textCapitalization: TextCapitalization.characters,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          labelText: 'Course Code',
                          hintText: 'e.g. CSE 325',
                          prefixIcon: Icon(Icons.menu_book_outlined),
                        ),
                        validator: Validators.courseCode,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _reasonController,
                        enabled: windowOpen,
                        minLines: 4,
                        maxLines: 6,
                        maxLength: 300,
                        decoration: const InputDecoration(
                          labelText: 'Reason for request',
                          alignLabelWithHint: true,
                        ),
                        validator: Validators.reason,
                      ),
                      const SizedBox(height: 8),
                      CustomButton(
                        label: 'Send request',
                        icon: Icons.send_rounded,
                        expand: true,
                        isLoading: advising.isSubmitting,
                        onPressed: windowOpen ? () => _send(advising) : null,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SectionHeader(
              'Your requests',
              trailing: Text(
                '${requests.length}',
                style: const TextStyle(color: AppColors.textMuted),
              ),
            ),
            if (requests.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  'You have not sent any requests yet.',
                  style: TextStyle(color: AppColors.textMuted),
                ),
              ),
            for (final r in requests)
              _RequestCard(
                request: r,
                isWithdrawing: _withdrawing.contains(r.id),
                onWithdraw: () => _withdraw(advising, r),
              ),
          ],
        );
      }),
    );
  }
}

class _RequestCard extends StatelessWidget {
  const _RequestCard({
    required this.request,
    required this.isWithdrawing,
    required this.onWithdraw,
  });

  final ExtraRequest request;
  final bool isWithdrawing;
  final VoidCallback onWithdraw;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: AppColors.border),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${request.courseCode} - ${request.status.label}',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                  ),
                ),
                StatusBadge.forRequest(request.status),
              ],
            ),
            const SizedBox(height: 6),
            Text(request.reason, style: const TextStyle(fontSize: 13)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Sent ${Formatters.dateTime(request.createdAt)}',
                    style: const TextStyle(fontSize: 11.5, color: AppColors.textMuted),
                  ),
                ),
                if (request.isPending)
                  CustomButton(
                    label: 'Withdraw',
                    variant: ButtonVariant.danger,
                    compact: true,
                    isLoading: isWithdrawing,
                    onPressed: onWithdraw,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
