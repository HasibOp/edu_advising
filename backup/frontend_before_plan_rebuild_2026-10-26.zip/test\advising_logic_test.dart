import 'package:edu_advising/data/mock_data.dart';
import 'package:edu_advising/models/extra_request.dart';
import 'package:edu_advising/models/offering.dart';
import 'package:edu_advising/models/schedule.dart';
import 'package:edu_advising/models/user.dart';
import 'package:edu_advising/providers/admin_provider.dart';
import 'package:edu_advising/providers/advising_provider.dart';
import 'package:edu_advising/providers/instructor_provider.dart';
import 'package:edu_advising/services/mock_api_service.dart';
import 'package:edu_advising/utils/validators.dart';
import 'package:flutter_test/flutter_test.dart';

Offering _offering({
  String id = 'x',
  String code = 'CSE 100',
  int capacity = 40,
  int taken = 0,
  List<ClassSchedule> schedule = const [],
}) {
  return Offering(
    id: id,
    courseCode: code,
    courseTitle: 'Test',
    section: 'A',
    semester: 10,
    credits: 3,
    capacity: capacity,
    seatsTaken: taken,
    facultyId: 'F',
    facultyName: 'F',
    schedule: schedule,
  );
}

void main() {
  group('Offering seat status', () {
    test('FULL when seats taken equals capacity', () {
      expect(_offering(taken: 40).seatStatus, SeatStatus.full);
    });
    test('low when 5 or fewer seats left', () {
      final o = _offering(taken: 35);
      expect(o.seatStatus, SeatStatus.low);
      expect(o.seatsLeft, 5);
    });
    test('OPEN otherwise', () {
      expect(_offering(taken: 12).seatStatus, SeatStatus.open);
    });
  });

  test('clash detection uses day and overlapping time', () {
    const sat830 = ClassSchedule(
        day: Weekday.sat, startTime: '08:30', endTime: '09:50', room: 'r');
    const sat900 = ClassSchedule(
        day: Weekday.sat, startTime: '09:00', endTime: '10:20', room: 'r');
    const sat1000 = ClassSchedule(
        day: Weekday.sat, startTime: '10:00', endTime: '11:20', room: 'r');
    const sun830 = ClassSchedule(
        day: Weekday.sun, startTime: '08:30', endTime: '09:50', room: 'r');

    final a = _offering(id: 'a', schedule: [sat830]);
    expect(a.clashesWith(_offering(id: 'b', schedule: [sat900])), isTrue);
    expect(a.clashesWith(_offering(id: 'c', schedule: [sat1000])), isFalse);
    expect(a.clashesWith(_offering(id: 'd', schedule: [sun830])), isFalse);
  });

  test('course codes are normalised', () {
    expect(Validators.normalizeCourseCode('cse325'), 'CSE 325');
    expect(Validators.normalizeCourseCode(' CSE-325 '), 'CSE 325');
    expect(Validators.normalizeCourseCode('hello'), isNull);
  });

  group('AdvisingProvider', () {
    late MockApiService api;
    late AdvisingProvider advising;

    setUp(() async {
      api = MockApiService(latency: Duration.zero);
      advising = AdvisingProvider(api);
      final student = await api.login(MockData.demoStudentId, 'pw');
      await advising.load(student);
    });

    Offering byId(String id) => advising.offeringById(id)!;

    test('full sections cannot be selected', () {
      expect(advising.toggle(byId('off-412-a')), contains('full'));
      expect(advising.isSelected(byId('off-412-a')), isFalse);
    });

    test('picking another section replaces the first one', () {
      advising.toggle(byId('off-421-a'));
      advising.toggle(byId('off-421-b'));
      expect(advising.isSelected(byId('off-421-a')), isFalse);
      expect(advising.isSelected(byId('off-421-b')), isTrue);
    });

    test('time clashes are rejected', () {
      advising.toggle(byId('off-300-a')); // Sat/Mon 08:30
      final error = advising.toggle(byId('off-325-a')); // full anyway
      expect(error, isNotNull);
      final clash = advising.toggle(byId('off-366-a')); // Sun/Tue 08:30, ok
      expect(clash, isNull);
      expect(advising.toggle(byId('off-430-a')), contains('clashes')); // Sun/Tue 08:30
    });

    test('select all picks one open section per course and confirm saves it',
        () async {
      final skipped = advising.setAllSelected(10, true);
      expect(skipped, 0);
      expect(advising.isAllSelected(10), isTrue);
      expect(advising.selectedCount, 4);

      final seatsBefore = byId('off-421-a').seatsTaken;
      expect(await advising.confirmAdvising(), isNull);
      expect(advising.enrolledOfferings.length, 4);
      expect(byId('off-421-a').seatsTaken, seatsBefore + 1);
      expect(advising.hasUnsavedChanges, isFalse);
    });

    test('not cleared students cannot advise', () async {
      await api.setClearance(MockData.demoStudentId, ClearanceStatus.notCleared);
      await advising.refresh();
      expect(advising.canAdvise, isFalse);
      expect(advising.toggle(byId('off-421-a')), isNotNull);
    });

    test('extra requests: duplicate pending is rejected, withdraw works',
        () async {
      // Seed data already has a pending CSE 325 request.
      expect(await advising.sendExtraRequest('cse325', 'Need it badly please'),
          contains('pending'));
      expect(await advising.sendExtraRequest('CSE 495', 'Elective for my thesis'),
          isNull);

      final pending =
          advising.extraRequests.firstWhere((r) => r.courseCode == 'CSE 325');
      expect(await advising.withdrawRequest(pending), isNull);
      expect(
        advising.extraRequests.firstWhere((r) => r.id == pending.id).status,
        RequestStatus.withdrawn,
      );
    });
  });

  test('instructor can drop and add courses', () async {
    final api = MockApiService(latency: Duration.zero);
    final panel = InstructorProvider(api);
    await panel.search('2021-1-60-022');
    expect(panel.student?.name, 'Nadia Sultana');
    expect(panel.enrolledCourses.length, 3);

    final course = panel.enrolledCourses.first;
    expect(await panel.drop(course.enrolment), isNull);
    expect(panel.enrolledCourses.length, 2);

    expect(await panel.addCourse(course.offering), isNull);
    expect(panel.enrolledCourses.length, 3);
  });

  test('admin clearance changes are visible to the student', () async {
    final api = MockApiService(latency: Duration.zero);
    final admin = AdminProvider(api);
    await admin.load();
    final student =
        admin.students.firstWhere((s) => s.studentId == '2021-2-60-008');
    expect(student.isCleared, isFalse);

    expect(await admin.setClearance(student, ClearanceStatus.cleared), isNull);
    expect((await api.findStudent('2021-2-60-008'))!.isCleared, isTrue);
  });
}
