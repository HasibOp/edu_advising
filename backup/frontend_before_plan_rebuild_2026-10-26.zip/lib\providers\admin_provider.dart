import 'package:flutter/foundation.dart';

import '../models/advising_windows.dart';
import '../models/user.dart';
import '../services/api_service.dart';

/// State for the admin panel: advising windows and student clearance.
///
/// Action methods return null on success or a message to show the user.
class AdminProvider extends ChangeNotifier {
  AdminProvider(this._api);

  final ApiService _api;

  AdvisingWindows _windows = const AdvisingWindows();
  List<User> _students = [];
  bool _isLoading = false;
  bool _isSavingWindows = false;
  String? _loadError;
  final Set<String> _busyIds = {};

  AdvisingWindows get windows => _windows;
  List<User> get students => _students;
  bool get isLoading => _isLoading;
  bool get isSavingWindows => _isSavingWindows;
  String? get loadError => _loadError;
  bool isBusy(String studentId) => _busyIds.contains(studentId);

  int get clearedCount => _students.where((s) => s.isCleared).length;

  Future<void> load() async {
    _isLoading = true;
    _loadError = null;
    notifyListeners();
    try {
      final windows = _api.fetchWindows();
      final students = _api.fetchStudents();
      _windows = await windows;
      _students = await students;
    } on ApiException catch (e) {
      _loadError = e.message;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> _saveWindows(AdvisingWindows next) async {
    final previous = _windows;
    _windows = next; // optimistic, so the switch moves immediately
    _isSavingWindows = true;
    notifyListeners();
    try {
      _windows = await _api.updateWindows(next);
      return null;
    } on ApiException catch (e) {
      _windows = previous;
      return e.message;
    } finally {
      _isSavingWindows = false;
      notifyListeners();
    }
  }

  Future<String?> setRegularAdvising(bool open) =>
      _saveWindows(_windows.copyWith(regularAdvising: open));

  Future<String?> setExtraCourse(bool open) =>
      _saveWindows(_windows.copyWith(extraCourse: open));

  Future<String?> setClearance(User student, ClearanceStatus status) async {
    _busyIds.add(student.studentId);
    notifyListeners();
    try {
      final updated = await _api.setClearance(student.studentId, status);
      _students = [
        for (final s in _students) s.studentId == updated.studentId ? updated : s,
      ];
      return null;
    } on ApiException catch (e) {
      return e.message;
    } finally {
      _busyIds.remove(student.studentId);
      notifyListeners();
    }
  }

  void clear() {
    _students = [];
    _windows = const AdvisingWindows();
    _busyIds.clear();
    _loadError = null;
    notifyListeners();
  }
}
