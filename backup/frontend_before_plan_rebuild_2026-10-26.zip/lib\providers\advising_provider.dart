import 'package:flutter/foundation.dart';

import '../models/advising_windows.dart';
import '../models/enrolment.dart';
import '../models/exam_schedule.dart';
import '../models/extra_request.dart';
import '../models/offering.dart';
import '../models/user.dart';
import '../services/api_service.dart';
import '../utils/validators.dart';

/// State for every student screen: advising selection, enrolled classes,
/// routine, offer list and extra course requests.
///
/// Action methods return null on success or a message to show the user.
class AdvisingProvider extends ChangeNotifier {
  AdvisingProvider(this._api);

  final ApiService _api;

  User? _student;
  List<Offering> _offerings = [];
  List<Enrolment> _enrolments = [];
  List<ExtraRequest> _requests = [];
  List<ExamSchedule> _exams = [];
  AdvisingWindows _windows = const AdvisingWindows();
  final Set<String> _selectedIds = {};

  bool _isLoading = false;
  bool _isSubmitting = false;
  String? _loadError;

  User? get student => _student;
  List<Offering> get offerings => _offerings;
  AdvisingWindows get windows => _windows;
  bool get isLoading => _isLoading;
  bool get isSubmitting => _isSubmitting;
  String? get loadError => _loadError;
  bool get hasData => _student != null && _offerings.isNotEmpty;

  bool get isCleared => _student?.isCleared ?? false;
  bool get canAdvise => isCleared && _windows.regularAdvising;

  /// Why the student can't change their advising right now, if they can't.
  String? get advisingBlockedReason {
    if (!isCleared) return 'You are not cleared for advising. Contact the accounts office.';
    if (!_windows.regularAdvising) return 'The regular advising window is closed.';
    return null;
  }

  // ---------------------------------------------------------------------------
  // Loading

  Future<void> load(User student) async {
    _student = student;
    _isLoading = true;
    _loadError = null;
    notifyListeners();
    try {
      final freshStudent = _api.findStudent(student.studentId);
      final offerings = _api.fetchOfferings();
      final enrolments = _api.fetchEnrolments(student.studentId);
      final requests = _api.fetchExtraRequests(student.studentId);
      final exams = _api.fetchExams();
      final windows = _api.fetchWindows();

      _student = await freshStudent ?? student;
      _offerings = await offerings;
      _enrolments = await enrolments;
      _requests = await requests;
      _exams = await exams;
      _windows = await windows;
      _resetSelection();
    } on ApiException catch (e) {
      _loadError = e.message;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> refresh() async {
    final student = _student;
    if (student != null) await load(student);
  }

  void clear() {
    _student = null;
    _offerings = [];
    _enrolments = [];
    _requests = [];
    _exams = [];
    _windows = const AdvisingWindows();
    _selectedIds.clear();
    _loadError = null;
    notifyListeners();
  }

  void _resetSelection() {
    _selectedIds
      ..clear()
      ..addAll(enrolledIds);
  }

  // ---------------------------------------------------------------------------
  // Offerings

  Offering? offeringById(String id) {
    for (final o in _offerings) {
      if (o.id == id) return o;
    }
    return null;
  }

  List<int> get semesters =>
      _offerings.map((o) => o.semester).toSet().toList()..sort();

  /// Sorted by course code then section. A null [semester] means all.
  List<Offering> offeringsFor(int? semester) {
    final list = _offerings
        .where((o) => semester == null || o.semester == semester)
        .toList()
      ..sort((a, b) {
        final byCode = a.courseCode.compareTo(b.courseCode);
        return byCode != 0 ? byCode : a.section.compareTo(b.section);
      });
    return list;
  }

  /// Offerings grouped by course code (insertion-ordered by code).
  Map<String, List<Offering>> groupByCourse(List<Offering> offerings) {
    final grouped = <String, List<Offering>>{};
    for (final o in offerings) {
      grouped.putIfAbsent(o.courseCode, () => []).add(o);
    }
    return grouped;
  }

  // ---------------------------------------------------------------------------
  // Enrolled classes & routine

  Set<String> get enrolledIds => _enrolments.map((e) => e.offeringId).toSet();

  bool isEnrolled(Offering o) => enrolledIds.contains(o.id);

  List<Offering> get enrolledOfferings {
    final list = _enrolments
        .map((e) => offeringById(e.offeringId))
        .whereType<Offering>()
        .toList()
      ..sort((a, b) => a.courseCode.compareTo(b.courseCode));
    return list;
  }

  int get enrolledCredits =>
      enrolledOfferings.fold(0, (sum, o) => sum + o.credits);

  List<ExamSchedule> get myExams {
    final codes = enrolledOfferings.map((o) => o.courseCode).toSet();
    return _exams.where((e) => codes.contains(e.courseCode)).toList()
      ..sort((a, b) {
        final byDate = a.date.compareTo(b.date);
        return byDate != 0 ? byDate : a.startTime.compareTo(b.startTime);
      });
  }

  // ---------------------------------------------------------------------------
  // Advising selection

  bool isSelected(Offering o) => _selectedIds.contains(o.id);

  List<Offering> get selectedOfferings =>
      _selectedIds.map(offeringById).whereType<Offering>().toList();

  int get selectedCount => _selectedIds.length;

  int get selectedCredits =>
      selectedOfferings.fold(0, (sum, o) => sum + o.credits);

  bool get hasUnsavedChanges => !setEquals(_selectedIds, enrolledIds);

  /// A full section can still be kept if the student already holds a seat.
  bool canPick(Offering o) => !o.isFull || isEnrolled(o);

  /// A selected section of another course that overlaps [o] in time.
  Offering? clashFor(Offering o) {
    for (final s in selectedOfferings) {
      if (s.courseCode != o.courseCode && s.clashesWith(o)) return s;
    }
    return null;
  }

  /// Selects or unselects [o]. Picking a section replaces any other section
  /// of the same course.
  String? toggle(Offering o) {
    final blocked = advisingBlockedReason;
    if (blocked != null) return blocked;

    if (_selectedIds.remove(o.id)) {
      notifyListeners();
      return null;
    }
    if (!canPick(o)) return '${o.displayName} is full.';
    final clash = clashFor(o);
    if (clash != null) {
      return '${o.displayName} clashes with ${clash.displayName}.';
    }

    _selectedIds.removeWhere((id) => offeringById(id)?.courseCode == o.courseCode);
    _selectedIds.add(o.id);
    notifyListeners();
    return null;
  }

  bool isAllSelected(int semester) {
    final courses = groupByCourse(offeringsFor(semester));
    return courses.isNotEmpty &&
        courses.values.every((sections) => sections.any(isSelected));
  }

  /// Selects one available section of every course in [semester], or clears
  /// them all. Returns how many courses could not be selected.
  int setAllSelected(int semester, bool selected) {
    if (advisingBlockedReason != null) return 0;
    final offerings = offeringsFor(semester);

    if (!selected) {
      _selectedIds.removeAll(offerings.map((o) => o.id));
      notifyListeners();
      return 0;
    }

    var skipped = 0;
    for (final sections in groupByCourse(offerings).values) {
      if (sections.any(isSelected)) continue;
      Offering? pick;
      for (final o in sections) {
        if (canPick(o) && clashFor(o) == null) {
          pick = o;
          break;
        }
      }
      if (pick == null) {
        skipped++;
      } else {
        _selectedIds.add(pick.id);
      }
    }
    notifyListeners();
    return skipped;
  }

  Future<String?> confirmAdvising() async {
    final student = _student;
    if (student == null) return 'Please sign in again.';
    final blocked = advisingBlockedReason;
    if (blocked != null) return blocked;
    if (_selectedIds.isEmpty) return 'Select at least one course.';

    _isSubmitting = true;
    notifyListeners();
    try {
      _enrolments =
          await _api.saveAdvising(student.studentId, _selectedIds.toList());
      _offerings = await _api.fetchOfferings();
      _resetSelection();
      return null;
    } on ApiException catch (e) {
      // Seat counts may have changed under us; show the latest.
      _offerings = await _api.fetchOfferings();
      return e.message;
    } finally {
      _isSubmitting = false;
      notifyListeners();
    }
  }

  // ---------------------------------------------------------------------------
  // Extra course requests

  List<ExtraRequest> get extraRequests => List.of(_requests)
    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  Future<String?> sendExtraRequest(String courseCode, String reason) async {
    final student = _student;
    if (student == null) return 'Please sign in again.';
    if (!_windows.extraCourse) return 'The extra course window is closed.';

    final code = Validators.normalizeCourseCode(courseCode);
    if (code == null) return 'Use a course code like CSE 325.';
    if (!_offerings.any((o) => o.courseCode == code)) {
      return '$code is not offered this term.';
    }
    if (enrolledOfferings.any((o) => o.courseCode == code)) {
      return 'You are already enrolled in $code.';
    }
    if (_requests.any((r) => r.courseCode == code && r.isPending)) {
      return 'You already have a pending request for $code.';
    }

    _isSubmitting = true;
    notifyListeners();
    try {
      final request =
          await _api.createExtraRequest(student.studentId, code, reason.trim());
      _requests = [..._requests, request];
      return null;
    } on ApiException catch (e) {
      return e.message;
    } finally {
      _isSubmitting = false;
      notifyListeners();
    }
  }

  Future<String?> withdrawRequest(ExtraRequest request) async {
    try {
      final updated =
          await _api.updateExtraRequestStatus(request.id, RequestStatus.withdrawn);
      _requests = [
        for (final r in _requests) r.id == updated.id ? updated : r,
      ];
      notifyListeners();
      return null;
    } on ApiException catch (e) {
      return e.message;
    }
  }
}
