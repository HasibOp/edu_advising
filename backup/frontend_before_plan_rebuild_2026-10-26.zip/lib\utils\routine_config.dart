import '../models/schedule.dart';

/// One row of the routine grid.
class TimeSlot {
  const TimeSlot(this.start, this.end);
  final String start;
  final String end;
}

class RoutineConfig {
  RoutineConfig._();

  static const List<Weekday> days = [
    Weekday.sat,
    Weekday.sun,
    Weekday.mon,
    Weekday.tue,
  ];

  static const List<TimeSlot> classSlots = [
    TimeSlot('08:30', '09:50'),
    TimeSlot('10:00', '11:20'),
    TimeSlot('11:30', '12:50'),
    TimeSlot('13:00', '14:20'),
    TimeSlot('14:30', '15:50'),
  ];

  static const List<TimeSlot> examSlots = [
    TimeSlot('09:00', '10:30'),
    TimeSlot('12:00', '13:30'),
    TimeSlot('15:00', '16:30'),
  ];
}
