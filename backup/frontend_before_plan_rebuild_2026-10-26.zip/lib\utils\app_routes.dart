import '../models/user.dart';

class AppRoutes {
  AppRoutes._();

  static const String login = '/login';

  // Student (all open the student shell on the matching tab)
  static const String advising = '/advising';
  static const String myClasses = '/my-classes';
  static const String routine = '/routine';
  static const String offerList = '/offer-list';
  static const String extraCourse = '/extra-course';

  static const String instructor = '/instructor';
  static const String admin = '/admin';

  static String homeFor(UserRole role) {
    switch (role) {
      case UserRole.admin:
        return admin;
      case UserRole.instructor:
        return instructor;
      case UserRole.student:
        return advising;
    }
  }
}
