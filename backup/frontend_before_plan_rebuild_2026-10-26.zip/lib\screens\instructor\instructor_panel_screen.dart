import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/mock_data.dart';
import '../../models/extra_request.dart';
import '../../models/offering.dart';
import '../../providers/auth_provider.dart';
import '../../providers/instructor_provider.dart';
import '../../utils/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/logout_button.dart';
import '../../widgets/notice_banner.dart';
import '../../widgets/seat_badge.dart';
import '../../widgets/state_views.dart';
import '../../widgets/status_badge.dart';

class InstructorPanelScreen extends StatefulWidget {
  const InstructorPanelScreen({super.key});

  @override
  State<InstructorPanelScreen> createState() => _InstructorPanelScreenState();
}

class _InstructorPanelScreenState extends State<InstructorPanelScreen> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _search([String? id]) {
    if (id != null) _searchController.text = id;
    FocusScope.of(context).unfocus();
    context.read<InstructorProvider>().search(_searchController.text);
  }

  void _show(String? error, String success) {
    showAppSnackBar(context, error ?? success, isError: error != null);
  }

  Future<void> _drop(InstructorProvider panel, EnrolledCourse course) async {
    final ok = await confirmDialog(
      context,
      title: 'Drop ${course.offering.displayName}?',
      message: 'The student will lose their seat in this section.',
      confirmLabel: 'Drop',
      destructive: true,
    );
    if (!ok || !mounted) return;
    final error = await panel.drop(course.enrolment);
    if (mounted) _show(error, '${course.offering.displayName} dropped.');
  }

  Future<void> _openAddCourse(InstructorProvider panel) async {
    final offering = await showModalBottomSheet<Offering>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: Colors.white,
      builder: (_) => _AddCourseSheet(offerings: panel.addableOfferings),
    );
    if (offering == null || !mounted) return;
    final error = await panel.addCourse(offering);
    if (mounted) _show(error, '${offering.displayName} added.');
  }

  Future<void> _review(InstructorProvider panel, ExtraRequest request) async {
    final approve = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Review ${request.courseCode}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sent ${Formatters.dateTime(request.createdAt)}',
              style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
            ),
            const SizedBox(height: 10),
            Text(request.reason),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Later'),
          ),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Reject'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.success),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Approve'),
          ),
        ],
      ),
    );
    if (approve == null || !mounted) return;
    final error = await panel.review(request, approve: approve);
    if (mounted) {
      _show(error, '${request.courseCode} request ${approve ? 'approved' : 'rejected'}.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final panel = context.watch<InstructorProvider>();
    final instructor = context.watch<AuthProvider>().currentUser;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Instructor Panel'),
            if (instructor != null)
              Text(
                instructor.name,
                style: const TextStyle(fontSize: 12, color: Colors.white70),
              ),
          ],
        ),
        actions: const [LogoutButton()],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _searchController,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _search(),
            decoration: InputDecoration(
              hintText: 'Student ID',
              prefixIcon: const Icon(Icons.person_search_outlined),
              suffixIcon: panel.isSearching
                  ? const Padding(
                      padding: EdgeInsets.all(14),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  : IconButton(
                      tooltip: 'Search',
                      icon: const Icon(Icons.search_rounded),
                      onPressed: _search,
                    ),
            ),
          ),
          if (panel.searchError != null) ...[
            const SizedBox(height: 8),
            Text(panel.searchError!, style: const TextStyle(color: AppColors.danger)),
          ],
          const SizedBox(height: 16),
          if (panel.student == null)
            _SearchHint(onPick: _search)
          else
            ..._buildStudentDetails(panel),
        ],
      ),
    );
  }

  List<Widget> _buildStudentDetails(InstructorProvider panel) {
    final student = panel.student!;
    final courses = panel.enrolledCourses;
    final requests = panel.requests;

    return [
      ClearanceBanner(student: student),
      SectionHeader(
        'Enrolled courses',
        trailing: Text(
          '${courses.length} courses  •  ${panel.enrolledCredits} cr',
          style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
        ),
      ),
      if (courses.isEmpty)
        const Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: Text('No enrolled courses.',
              style: TextStyle(color: AppColors.textMuted)),
        ),
      for (final c in courses)
        _CourseRow(
          offering: c.offering,
          action: CustomButton(
            label: 'DROP',
            variant: ButtonVariant.danger,
            compact: true,
            isLoading: panel.isBusy(c.enrolment.id),
            onPressed: () => _drop(panel, c),
          ),
        ),
      const SizedBox(height: 4),
      CustomButton(
        label: 'Add course',
        icon: Icons.add_rounded,
        expand: true,
        onPressed: () => _openAddCourse(panel),
      ),
      const SectionHeader('Extra requests'),
      if (requests.isEmpty)
        const Text('No extra course requests.',
            style: TextStyle(color: AppColors.textMuted)),
      for (final r in requests)
        _RequestRow(
          request: r,
          action: r.isPending
              ? CustomButton(
                  label: 'REVIEW',
                  variant: ButtonVariant.warning,
                  compact: true,
                  isLoading: panel.isBusy(r.id),
                  onPressed: () => _review(panel, r),
                )
              : StatusBadge.forRequest(r.status),
        ),
    ];
  }
}

class _SearchHint extends StatelessWidget {
  const _SearchHint({required this.onPick});

  final ValueChanged<String> onPick;

  @override
  Widget build(BuildContext context) {
    const sampleIds = ['2021-1-60-022', MockData.demoStudentId, '2021-2-60-008'];
    return Column(
      children: [
        const EmptyState(
          icon: Icons.manage_search_rounded,
          title: 'Look up a student',
          message: 'Search by student ID to see clearance, courses and requests.',
        ),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          alignment: WrapAlignment.center,
          children: [
            for (final id in sampleIds)
              ActionChip(label: Text(id), onPressed: () => onPick(id)),
          ],
        ),
      ],
    );
  }
}

class _CardShell extends StatelessWidget {
  const _CardShell({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: AppColors.border),
      ),
      child: Padding(padding: const EdgeInsets.all(14), child: child),
    );
  }
}

class _CourseRow extends StatelessWidget {
  const _CourseRow({required this.offering, required this.action});

  final Offering offering;
  final Widget action;

  @override
  Widget build(BuildContext context) {
    return _CardShell(
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(offering.displayName,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                Text(offering.courseTitle,
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                const SizedBox(height: 4),
                Text(Formatters.schedule(offering), style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          action,
        ],
      ),
    );
  }
}

class _RequestRow extends StatelessWidget {
  const _RequestRow({required this.request, required this.action});

  final ExtraRequest request;
  final Widget action;

  @override
  Widget build(BuildContext context) {
    return _CardShell(
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${request.courseCode} - ${request.status.label}',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                ),
                const SizedBox(height: 2),
                Text(
                  request.reason,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12.5, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          action,
        ],
      ),
    );
  }
}

/// Bottom sheet listing sections the student can be added to.
class _AddCourseSheet extends StatelessWidget {
  const _AddCourseSheet({required this.offerings});

  final List<Offering> offerings;

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      maxChildSize: 0.92,
      builder: (context, controller) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 8),
            child: Text(
              'Add course',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
          ),
          Expanded(
            child: offerings.isEmpty
                ? const EmptyState(
                    icon: Icons.check_circle_outline_rounded,
                    title: 'Nothing left to add',
                  )
                : ListView.separated(
                    controller: controller,
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                    itemCount: offerings.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, i) {
                      final o = offerings[i];
                      return ListTile(
                        enabled: !o.isFull,
                        onTap: () => Navigator.pop(context, o),
                        title: Text(
                          o.displayName,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: Text(
                          '${o.courseTitle}  •  Sem ${o.semester}\n'
                          '${Formatters.schedule(o)}',
                          style: const TextStyle(fontSize: 12),
                        ),
                        isThreeLine: true,
                        trailing: SeatBadge(offering: o),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
