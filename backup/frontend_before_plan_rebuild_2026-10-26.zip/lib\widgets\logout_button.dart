import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/admin_provider.dart';
import '../providers/advising_provider.dart';
import '../providers/auth_provider.dart';
import '../providers/instructor_provider.dart';
import '../utils/app_routes.dart';

class LogoutButton extends StatelessWidget {
  const LogoutButton({super.key});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: 'Sign out',
      icon: const Icon(Icons.logout_rounded),
      onPressed: () {
        context.read<AuthProvider>().logout();
        context.read<AdvisingProvider>().clear();
        context.read<InstructorProvider>().clear();
        context.read<AdminProvider>().clear();
        Navigator.of(context)
            .pushNamedAndRemoveUntil(AppRoutes.login, (_) => false);
      },
    );
  }
}
