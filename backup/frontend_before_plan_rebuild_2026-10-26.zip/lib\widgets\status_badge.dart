import 'package:flutter/material.dart';

import '../models/extra_request.dart';
import '../utils/app_theme.dart';

/// A small solid pill such as "OPEN", "FULL" or "Pending".
class StatusBadge extends StatelessWidget {
  const StatusBadge({
    super.key,
    required this.label,
    required this.color,
    this.textColor = Colors.white,
    this.icon,
  });

  const StatusBadge.success(this.label, {super.key, this.icon})
      : color = AppColors.success,
        textColor = Colors.white;

  const StatusBadge.warning(this.label, {super.key, this.icon})
      : color = AppColors.warning,
        textColor = AppColors.onWarning;

  const StatusBadge.danger(this.label, {super.key, this.icon})
      : color = AppColors.danger,
        textColor = Colors.white;

  factory StatusBadge.forRequest(RequestStatus status, {Key? key}) {
    switch (status) {
      case RequestStatus.pending:
        return StatusBadge.warning(status.label, key: key);
      case RequestStatus.approved:
        return StatusBadge.success(status.label, key: key);
      case RequestStatus.rejected:
        return StatusBadge.danger(status.label, key: key);
      case RequestStatus.withdrawn:
        return StatusBadge(
          label: status.label,
          color: Colors.grey.shade400,
          textColor: Colors.black87,
          key: key,
        );
    }
  }

  final String label;
  final Color color;
  final Color textColor;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 13, color: textColor),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: TextStyle(
              color: textColor,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}
