import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/offering.dart';
import '../../providers/advising_provider.dart';
import '../../utils/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/logout_button.dart';
import '../../widgets/seat_badge.dart';
import '../../widgets/state_views.dart';
import 'student_async_body.dart';

class OfferListScreen extends StatefulWidget {
  const OfferListScreen({super.key});

  @override
  State<OfferListScreen> createState() => _OfferListScreenState();
}

class _OfferListScreenState extends State<OfferListScreen> {
  final _searchController = TextEditingController();
  String _query = '';

  /// null means "All".
  int? _semester;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  bool _matches(Offering o) {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return true;
    return o.courseCode.toLowerCase().contains(q) ||
        o.courseCode.replaceAll(' ', '').toLowerCase().contains(q) ||
        o.courseTitle.toLowerCase().contains(q) ||
        o.facultyName.toLowerCase().contains(q);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Offer List'),
        actions: const [LogoutButton()],
      ),
      body: StudentAsyncBody(builder: (context) {
        final advising = context.watch<AdvisingProvider>();
        final courses = advising.groupByCourse(
          advising.offeringsFor(_semester).where(_matches).toList(),
        );

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: TextField(
                controller: _searchController,
                onChanged: (v) => setState(() => _query = v),
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'Search course, title or faculty',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'Clear',
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () {
                            _searchController.clear();
                            setState(() => _query = '');
                          },
                        ),
                ),
              ),
            ),
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  _FilterChip(
                    label: 'All',
                    selected: _semester == null,
                    onSelected: () => setState(() => _semester = null),
                  ),
                  for (final s in advising.semesters)
                    _FilterChip(
                      label: 'Sem $s',
                      selected: _semester == s,
                      onSelected: () => setState(() => _semester = s),
                    ),
                ],
              ),
            ),
            Expanded(
              child: courses.isEmpty
                  ? const EmptyState(
                      icon: Icons.search_off_rounded,
                      title: 'No courses match your search',
                    )
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      children: [
                        for (final entry in courses.entries)
                          _CourseTile(courseCode: entry.key, sections: entry.value),
                      ],
                    ),
            ),
          ],
        );
      }),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onSelected,
  });

  final String label;
  final bool selected;
  final VoidCallback onSelected;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onSelected(),
      ),
    );
  }
}

class _CourseTile extends StatelessWidget {
  const _CourseTile({required this.courseCode, required this.sections});

  final String courseCode;
  final List<Offering> sections;

  @override
  Widget build(BuildContext context) {
    final first = sections.first;
    final openSeats = sections.fold<int>(0, (sum, o) => sum + o.seatsLeft);

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      color: Colors.white,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: AppColors.border),
      ),
      child: ExpansionTile(
        shape: const Border(),
        collapsedShape: const Border(),
        leading: CircleAvatar(
          backgroundColor: AppColors.blockColorFor(courseCode),
          child: Text(
            '${first.semester}',
            style: const TextStyle(
                color: AppColors.primaryDark, fontWeight: FontWeight.w700),
          ),
        ),
        title: Text(courseCode, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(
          '${first.courseTitle}\n${sections.length} section${sections.length == 1 ? '' : 's'}  •  $openSeats seats open',
          style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
        children: [
          for (final o in sections) _SectionRow(offering: o),
        ],
      ),
    );
  }
}

class _SectionRow extends StatelessWidget {
  const _SectionRow({required this.offering});

  final Offering offering;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Sec ${offering.section}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 2),
                Text(Formatters.schedule(offering), style: const TextStyle(fontSize: 12)),
                Text(
                  '${offering.facultyName}  •  ${Formatters.rooms(offering)}',
                  style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              SeatBadge(offering: offering),
              const SizedBox(height: 4),
              Text(
                '${offering.seatsTaken}/${offering.capacity}',
                style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
