import 'package:flutter/foundation.dart';

import '../models/enrolment.dart';
import '../models/extra_request.dart';
import '../models/offering.dart';
import '../models/user.dart';
import '../services/api_service.dart';

/// An active enrolment together with the section it refers to.
typedef EnrolledCourse = ({Enrolment enrolment, Offering offering});

/// State for the instructor panel: look up a student, then drop/add their
/// courses and review their extra course requests.
///
/// Action methods return null on success or a message to show the user.
class InstructorProvider extends ChangeNotifier {
  InstructorProvider(this._api);

  final ApiService _api;

  User? _student;
  List<Enrolment> _enrolments = [];
  List<ExtraRequest> _requests = [];
  List<Offering> _offerings = [];
  bool _isSearching = false;
  String? _searchError;
  final Set<String> _busyIds = {};

  User? get student => _student;
  bool get isSearching => _isSearching;
  String? get searchError => _searchError;

  /// True while an action on this enrolment/request id is in flight.
  bool isBusy(String id) => _busyIds.contains(id);

  List<EnrolledCourse> get enrolledCourses {
    final result = <EnrolledCourse>[];
    for (final e in _enrolments) {
      for (final o in _offerings) {
        if (o.id == e.offeringId) result.add((enrolment: e, offering: o));
      }
    }
    result.sort((a, b) => a.offering.courseCode.compareTo(b.offering.courseCode));
    return result;
  }

  int get enrolledCredits =>
      enrolledCourses.fold(0, (sum, c) => sum + c.offering.credits);

  List<ExtraRequest> get requests => List.of(_requests)
    ..sort((a, b) {
      // Pending first, then newest.
      if (a.isPending != b.isPending) return a.isPending ? -1 : 1;
      return b.createdAt.compareTo(a.createdAt);
    });

  /// Sections the student could be added to: courses they don't already take.
  List<Offering> get addableOfferings {
    final takenCodes = enrolledCourses.map((c) => c.offering.courseCode).toSet();
    return _offerings.where((o) => !takenCodes.contains(o.courseCode)).toList()
      ..sort((a, b) {
        final bySemester = a.semester.compareTo(b.semester);
        if (bySemester != 0) return bySemester;
        final byCode = a.courseCode.compareTo(b.courseCode);
        return byCode != 0 ? byCode : a.section.compareTo(b.section);
      });
  }

  Future<void> search(String studentId) async {
    final id = studentId.trim();
    if (id.isEmpty) {
      _searchError = 'Enter a student ID.';
      notifyListeners();
      return;
    }

    _isSearching = true;
    _searchError = null;
    notifyListeners();
    try {
      final student = await _api.findStudent(id);
      if (student == null) {
        _student = null;
        _searchError = 'No student found with ID "$id".';
        return;
      }
      final enrolments = _api.fetchEnrolments(id);
      final requests = _api.fetchExtraRequests(id);
      final offerings = _api.fetchOfferings();
      _student = student;
      _enrolments = await enrolments;
      _requests = await requests;
      _offerings = await offerings;
    } on ApiException catch (e) {
      _searchError = e.message;
    } finally {
      _isSearching = false;
      notifyListeners();
    }
  }

  Future<void> _reloadStudent() async {
    final student = _student;
    if (student == null) return;
    _enrolments = await _api.fetchEnrolments(student.studentId);
    _offerings = await _api.fetchOfferings();
  }

  Future<String?> _run(String busyId, Future<void> Function() action) async {
    _busyIds.add(busyId);
    notifyListeners();
    try {
      await action();
      return null;
    } on ApiException catch (e) {
      return e.message;
    } finally {
      _busyIds.remove(busyId);
      notifyListeners();
    }
  }

  Future<String?> drop(Enrolment enrolment) => _run(enrolment.id, () async {
        await _api.dropEnrolment(enrolment.id);
        await _reloadStudent();
      });

  Future<String?> addCourse(Offering offering) {
    final student = _student;
    if (student == null) return Future.value('Search for a student first.');
    return _run(offering.id, () async {
      await _api.addEnrolment(student.studentId, offering.id);
      await _reloadStudent();
    });
  }

  Future<String?> review(ExtraRequest request, {required bool approve}) =>
      _run(request.id, () async {
        final updated = await _api.updateExtraRequestStatus(
          request.id,
          approve ? RequestStatus.approved : RequestStatus.rejected,
        );
        _requests = [
          for (final r in _requests) r.id == updated.id ? updated : r,
        ];
      });

  void clear() {
    _student = null;
    _enrolments = [];
    _requests = [];
    _offerings = [];
    _searchError = null;
    _busyIds.clear();
    notifyListeners();
  }
}
