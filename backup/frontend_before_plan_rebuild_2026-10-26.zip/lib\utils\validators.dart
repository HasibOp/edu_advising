class Validators {
  Validators._();

  static final RegExp _courseCode = RegExp(r'^([A-Za-z]{2,4})\s*-?\s*(\d{3})$');

  /// Normalises "cse325", "CSE-325" or "cse 325" to "CSE 325".
  /// Returns null when the input is not a course code.
  static String? normalizeCourseCode(String input) {
    final match = _courseCode.firstMatch(input.trim());
    if (match == null) return null;
    return '${match.group(1)!.toUpperCase()} ${match.group(2)}';
  }

  static String? required(String? value, String field) {
    if (value == null || value.trim().isEmpty) return 'Enter your $field';
    return null;
  }

  static String? courseCode(String? value) {
    if (value == null || value.trim().isEmpty) return 'Enter a course code';
    if (normalizeCourseCode(value) == null) return 'Use a code like CSE 325';
    return null;
  }

  static String? reason(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return 'Tell your advisor why you need this course';
    if (text.length < 15) return 'Please write at least 15 characters';
    return null;
  }
}
