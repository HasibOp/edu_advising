import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Brand and status colours used across the app.
class AppColors {
  AppColors._();

  static const Color primary = Color(0xFF6B1D45);
  static const Color primaryDark = Color(0xFF4A1230);
  static const Color success = Color(0xFF2E7D32);
  static const Color warning = Color(0xFFF9A826);
  static const Color danger = Color(0xFFD32F2F);

  /// Text colour that stays readable on top of [warning].
  static const Color onWarning = Color(0xFF3D2A00);

  static const Color background = Color(0xFFF8F4F6);
  static const Color surface = Colors.white;
  static const Color border = Color(0xFFE6DCE1);
  static const Color textMuted = Color(0xFF6E6470);

  /// Soft fills for routine blocks. A course always maps to the same colour.
  static const List<Color> blockColors = [
    Color(0xFFF8D7E3), // light pink
    Color(0xFFDCEBFA), // light blue
    Color(0xFFDFF3E3), // light green
    Color(0xFFFFF0CC), // light yellow
    Color(0xFFE8DEF8), // light purple
    Color(0xFFFFE0D1), // light peach
  ];

  static Color blockColorFor(String key) {
    final hash = key.codeUnits.fold<int>(0, (sum, unit) => sum + unit);
    return blockColors[hash % blockColors.length];
  }
}

class AppTheme {
  AppTheme._();

  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      primary: AppColors.primary,
      onPrimary: Colors.white,
      error: AppColors.danger,
    );
    final base = ThemeData(useMaterial3: true, colorScheme: scheme);
    final textTheme = GoogleFonts.poppinsTextTheme(base.textTheme);

    return base.copyWith(
      scaffoldBackgroundColor: AppColors.background,
      textTheme: textTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.poppins(
          fontSize: 19,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.6),
        ),
      ),
      snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
      dividerColor: AppColors.border,
    );
  }
}
