import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'models/user.dart';
import 'providers/admin_provider.dart';
import 'providers/advising_provider.dart';
import 'providers/auth_provider.dart';
import 'providers/instructor_provider.dart';
import 'screens/admin/admin_panel_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/instructor/instructor_panel_screen.dart';
import 'screens/student/student_shell.dart';
import 'services/api_service.dart';
import 'services/mock_api_service.dart';
import 'utils/app_routes.dart';
import 'utils/app_theme.dart';

void main() {
  runApp(EduAdvisingApp(api: MockApiService()));
}

class EduAdvisingApp extends StatelessWidget {
  const EduAdvisingApp({super.key, required this.api});

  /// Swap [MockApiService] for a real implementation once the backend exists.
  final ApiService api;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<ApiService>.value(value: api),
        ChangeNotifierProvider(create: (_) => AuthProvider(api)),
        ChangeNotifierProvider(create: (_) => AdvisingProvider(api)),
        ChangeNotifierProvider(create: (_) => InstructorProvider(api)),
        ChangeNotifierProvider(create: (_) => AdminProvider(api)),
      ],
      child: MaterialApp(
        title: 'EDU Advising',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        initialRoute: AppRoutes.login,
        routes: {
          AppRoutes.login: (_) => const LoginScreen(),
          AppRoutes.advising: (context) => _guard(context, UserRole.student,
              const StudentShell(initialTab: StudentTab.advising)),
          AppRoutes.myClasses: (context) => _guard(context, UserRole.student,
              const StudentShell(initialTab: StudentTab.myClasses)),
          AppRoutes.routine: (context) => _guard(context, UserRole.student,
              const StudentShell(initialTab: StudentTab.routine)),
          AppRoutes.offerList: (context) => _guard(context, UserRole.student,
              const StudentShell(initialTab: StudentTab.offerList)),
          AppRoutes.extraCourse: (context) => _guard(context, UserRole.student,
              const StudentShell(initialTab: StudentTab.extraCourse)),
          AppRoutes.instructor: (context) => _guard(
              context, UserRole.instructor, const InstructorPanelScreen()),
          AppRoutes.admin: (context) =>
              _guard(context, UserRole.admin, const AdminPanelScreen()),
        },
      ),
    );
  }

  /// Sends signed-out users (or the wrong role) back to the login screen.
  static Widget _guard(BuildContext context, UserRole role, Widget screen) {
    final user = context.read<AuthProvider>().currentUser;
    if (user == null || user.role != role) return const LoginScreen();
    return screen;
  }
}
