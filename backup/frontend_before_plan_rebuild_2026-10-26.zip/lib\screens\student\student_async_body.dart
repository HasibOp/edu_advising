import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/advising_provider.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/state_views.dart';

/// Shows a spinner or a retry message until the student's data is loaded,
/// then builds the real screen body.
class StudentAsyncBody extends StatelessWidget {
  const StudentAsyncBody({super.key, required this.builder});

  final WidgetBuilder builder;

  @override
  Widget build(BuildContext context) {
    final advising = context.watch<AdvisingProvider>();
    if (advising.hasData) return builder(context);
    if (advising.loadError != null && !advising.isLoading) {
      return EmptyState(
        icon: Icons.cloud_off_rounded,
        title: 'Could not load your advising data',
        message: advising.loadError,
        action: CustomButton(
          label: 'Try again',
          icon: Icons.refresh_rounded,
          onPressed: advising.refresh,
        ),
      );
    }
    return const LoadingView();
  }
}
