import 'package:flutter/material.dart';

import '../models/offering.dart';
import 'status_badge.dart';

/// Red "FULL", gold "X left" (5 or fewer seats) or green "OPEN".
class SeatBadge extends StatelessWidget {
  const SeatBadge({super.key, required this.offering});

  final Offering offering;

  @override
  Widget build(BuildContext context) {
    switch (offering.seatStatus) {
      case SeatStatus.full:
        return const StatusBadge.danger('FULL');
      case SeatStatus.low:
        return StatusBadge.warning('${offering.seatsLeft} left');
      case SeatStatus.open:
        return const StatusBadge.success('OPEN');
    }
  }
}
