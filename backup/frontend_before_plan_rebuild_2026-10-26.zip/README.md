# EDU Advising (Flutter frontend)

Course advising app for students, instructors and admins. Flutter + Material 3,
MVVM with Provider, running on hardcoded mock data until the backend is ready.

## Run it

```bash
cd edu_advising
flutter pub get
flutter run -d chrome     # or pick your Android emulator
flutter test              # unit tests for the advising rules
```

Note: `flutter test` fails if the project path contains an apostrophe
(e.g. `Hasib's Study`). This is a Flutter tooling bug. Keep the project in a
folder without `'` in its path.

## Demo accounts (any password)

| Login ID         | Goes to            | Notes                                   |
|------------------|--------------------|-----------------------------------------|
| `2021-1-60-015`  | Student dashboard  | Sem 10, cleared, pending CSE 325 request |
| `2021-1-60-022`  | Student dashboard  | Already enrolled in 3 courses           |
| `2021-2-60-008`  | Student dashboard  | Not cleared (red banner)                |
| `instructor`     | Instructor Panel   |                                         |
| `admin`          | Admin Panel        |                                         |

Any other ID signs in as a new Semester 10 student. Mock data lives for the
app session, so you can e.g. revoke a student's clearance as `admin`, sign out,
and sign in as that student to see the red banner.

## Structure

```
lib/
 ├── models/        User, Offering, Enrolment, ExtraRequest, ExamSchedule, AdvisingWindows
 ├── providers/     AuthProvider, AdvisingProvider (student), InstructorProvider, AdminProvider
 ├── services/      ApiService (interface) + MockApiService (in-memory backend)
 ├── data/          mock_data.dart: seed students, offerings, requests, exams
 ├── screens/
 │    ├── auth/        login_screen.dart
 │    ├── student/     student_shell (bottom nav), advising, my_classes, routine, offer_list, extra_course
 │    ├── instructor/  instructor_panel_screen.dart
 │    └── admin/       admin_panel_screen.dart
 ├── widgets/       CustomButton, StatusBadge, SeatBadge, OfferingCard, banners, RoutineGrid
 ├── utils/         app_theme, app_routes, formatters, validators, pdf_generator, routine_config
 └── main.dart
```

## Rules implemented in the mock

- Seat badge: `FULL` (red) when full, `X left` (gold) at 5 or fewer seats, else `OPEN` (green).
- One section per course; picking another section swaps it. Time clashes are blocked.
- "Select all" picks the first open, non-clashing section of every course in the chosen semester.
- Advising needs clearance **and** the Regular advising window ON (Admin panel).
- Extra requests need the Extra course window ON; one pending request per course; pending requests can be withdrawn.
- Instructors can DROP/add a student's courses and approve/reject extra requests.

## Connecting the backend later

Screens never call the API directly. They go through the providers, which use
the `ApiService` interface in `lib/services/api_service.dart`. To switch to
the real backend:

1. Create `HttpApiService implements ApiService` (e.g. with the `http` or `dio` package).
2. Every model already has `fromJson` / `toJson`. Match the backend's JSON to those keys.
3. In `main.dart`, replace `MockApiService()` with `HttpApiService(baseUrl: ...)`.
4. Throw `ApiException('message')` for errors that should be shown to the user.
