import 'schedule.dart';

class ExamSchedule {
  const ExamSchedule({
    required this.courseCode,
    required this.type,
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.room,
  });

  final String courseCode;

  /// e.g. "Midterm", "Final"
  final String type;
  final DateTime date;
  final String startTime;
  final String endTime;
  final String room;

  Weekday get day => Weekday.fromDate(date);

  factory ExamSchedule.fromJson(Map<String, dynamic> json) {
    return ExamSchedule(
      courseCode: json['courseCode'] as String,
      type: json['type'] as String,
      date: DateTime.parse(json['date'] as String),
      startTime: json['startTime'] as String,
      endTime: json['endTime'] as String,
      room: json['room'] as String,
    );
  }

  Map<String, dynamic> toJson() => {
        'courseCode': courseCode,
        'type': type,
        'date': date.toIso8601String(),
        'startTime': startTime,
        'endTime': endTime,
        'room': room,
      };
}
