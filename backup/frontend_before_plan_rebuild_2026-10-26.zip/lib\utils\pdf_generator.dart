import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../models/offering.dart';
import '../models/schedule.dart';
import '../models/user.dart';
import 'formatters.dart';
import 'routine_config.dart';

/// A filled cell of a routine table in the PDF.
class PdfRoutineCell {
  const PdfRoutineCell({
    required this.day,
    required this.startTime,
    required this.lines,
  });

  final Weekday day;
  final String startTime;
  final List<String> lines;
}

/// Builds the PDFs offered by "Download PDF" buttons.
///
/// Text here is plain ASCII because the built-in PDF font (Helvetica)
/// cannot render most Unicode symbols.
class PdfGenerator {
  PdfGenerator._();

  static const PdfColor _maroon = PdfColor.fromInt(0xFF6B1D45);
  static const PdfColor _pink = PdfColor.fromInt(0xFFF8D7E3);
  static const PdfColor _grey = PdfColor.fromInt(0xFF6E6470);

  static Future<Uint8List> classList({
    required User student,
    required List<Offering> offerings,
  }) {
    final doc = pw.Document(title: 'My Classes', author: 'EDU Advising');
    final totalCredits = offerings.fold<int>(0, (sum, o) => sum + o.credits);

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        header: (_) => _header('My Classes', student),
        footer: _footer,
        build: (_) => [
          pw.TableHelper.fromTextArray(
            headers: ['Course', 'Title', 'Sec', 'Cr', 'Schedule', 'Room', 'Faculty'],
            data: [
              for (final o in offerings)
                [
                  o.courseCode,
                  o.courseTitle,
                  o.section,
                  '${o.credits}',
                  Formatters.schedule(o),
                  Formatters.rooms(o),
                  o.facultyName,
                ],
            ],
            headerStyle: const pw.TextStyle(
                color: PdfColors.white, fontWeight: pw.FontWeight.bold, fontSize: 10),
            headerDecoration: const pw.BoxDecoration(color: _maroon),
            cellStyle: const pw.TextStyle(fontSize: 9),
            cellAlignment: pw.Alignment.centerLeft,
            oddRowDecoration: const pw.BoxDecoration(color: PdfColors.grey100),
            border: null,
            cellPadding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 6),
          ),
          pw.SizedBox(height: 16),
          pw.Text(
            'Total: ${offerings.length} courses, $totalCredits credits',
            style: const pw.TextStyle(fontWeight: pw.FontWeight.bold),
          ),
        ],
      ),
    );
    return doc.save();
  }

  static Future<Uint8List> routine({
    required String title,
    required User student,
    required List<TimeSlot> slots,
    required List<PdfRoutineCell> cells,
  }) {
    final doc = pw.Document(title: title, author: 'EDU Advising');
    const days = RoutineConfig.days;

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(32),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            _header(title, student),
            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
              columnWidths: {0: const pw.FlexColumnWidth(1.2)},
              children: [
                pw.TableRow(children: [
                  _cell('Time', color: _maroon, bold: true, textColor: PdfColors.white),
                  for (final d in days)
                    _cell(d.full, color: _maroon, bold: true, textColor: PdfColors.white),
                ]),
                for (final slot in slots)
                  pw.TableRow(children: [
                    _cell(Formatters.timeRange(slot.start, slot.end), bold: true),
                    for (final d in days) _routineCell(cells, d, slot),
                  ]),
              ],
            ),
            pw.Spacer(),
            _footer(context),
          ],
        ),
      ),
    );
    return doc.save();
  }

  static pw.Widget _routineCell(
      List<PdfRoutineCell> cells, Weekday day, TimeSlot slot) {
    final matches =
        cells.where((c) => c.day == day && c.startTime == slot.start).toList();
    if (matches.isEmpty) return _cell('');
    return _cell(
      matches.map((m) => m.lines.join('\n')).join('\n'),
      color: _pink,
      bold: true,
    );
  }

  static pw.Widget _cell(
    String text, {
    PdfColor? color,
    bool bold = false,
    PdfColor textColor = PdfColors.black,
  }) {
    return pw.Container(
      height: 52,
      alignment: pw.Alignment.center,
      padding: const pw.EdgeInsets.all(4),
      color: color,
      child: pw.Text(
        text,
        textAlign: pw.TextAlign.center,
        style: pw.TextStyle(
          fontSize: 9,
          color: textColor,
          fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
        ),
      ),
    );
  }

  static pw.Widget _header(String title, User student) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 16),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            color: _maroon,
            child: pw.Text(
              'EDU Advising - $title',
              style: const pw.TextStyle(
                  color: PdfColors.white, fontSize: 16, fontWeight: pw.FontWeight.bold),
            ),
          ),
          pw.SizedBox(height: 8),
          pw.Text(
            '${student.name}   |   ID: ${student.studentId}   |   Semester ${student.semester}',
            style: const pw.TextStyle(fontSize: 11),
          ),
        ],
      ),
    );
  }

  static pw.Widget _footer(pw.Context context) {
    return pw.Container(
      alignment: pw.Alignment.centerRight,
      margin: const pw.EdgeInsets.only(top: 12),
      child: pw.Text(
        'Generated ${Formatters.dateTime(DateTime.now())}   Page ${context.pageNumber}/${context.pagesCount}',
        style: const pw.TextStyle(fontSize: 8, color: _grey),
      ),
    );
  }

  /// Opens the system share/save sheet (downloads the file on web).
  static Future<void> share(Uint8List bytes, String filename) async {
    await Printing.sharePdf(bytes: bytes, filename: filename);
  }
}
