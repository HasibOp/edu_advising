import 'package:flutter/material.dart';

import '../models/schedule.dart';
import '../utils/app_theme.dart';
import '../utils/formatters.dart';
import '../utils/routine_config.dart';

/// One coloured block in the routine grid.
class RoutineBlock {
  const RoutineBlock({
    required this.day,
    required this.startTime,
    required this.title,
    required this.subtitle,
    required this.color,
  });

  final Weekday day;
  final String startTime;
  final String title;
  final String subtitle;
  final Color color;
}

/// Weekly timetable: a header row of days, then one row per time slot.
class RoutineGrid extends StatelessWidget {
  const RoutineGrid({
    super.key,
    required this.slots,
    required this.blocks,
    this.days = RoutineConfig.days,
  });

  final List<Weekday> days;
  final List<TimeSlot> slots;
  final List<RoutineBlock> blocks;

  static const double _gap = 4;

  @override
  Widget build(BuildContext context) {
    final columns = days.length + 1;
    return Column(
      children: [
        Row(
          children: [
            for (var i = 0; i < columns; i++) ...[
              if (i > 0) const SizedBox(width: _gap),
              Expanded(
                child: Container(
                  height: 34,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: i == 0 ? AppColors.primaryDark : AppColors.primary,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    i == 0 ? 'Time' : days[i - 1].short,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 12.5,
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: _gap),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.zero,
          itemCount: slots.length * columns,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            mainAxisExtent: 66,
            crossAxisSpacing: _gap,
            mainAxisSpacing: _gap,
          ),
          itemBuilder: (context, index) {
            final slot = slots[index ~/ columns];
            final column = index % columns;
            if (column == 0) return _TimeCell(slot: slot);
            final day = days[column - 1];
            final matches = blocks
                .where((b) => b.day == day && b.startTime == slot.start)
                .toList();
            return _BlockCell(blocks: matches);
          },
        ),
      ],
    );
  }
}

class _TimeCell extends StatelessWidget {
  const _TimeCell({required this.slot});

  final TimeSlot slot;

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Text(
          '${Formatters.time(slot.start)}\n${Formatters.time(slot.end)}',
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 10.5,
            height: 1.35,
            fontWeight: FontWeight.w600,
            color: AppColors.textMuted,
          ),
        ),
      ),
    );
  }
}

class _BlockCell extends StatelessWidget {
  const _BlockCell({required this.blocks});

  final List<RoutineBlock> blocks;

  @override
  Widget build(BuildContext context) {
    if (blocks.isEmpty) {
      return Container(
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(140),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.border),
        ),
      );
    }

    final block = blocks.first;
    final subtitle = blocks.length > 1
        ? '+${blocks.length - 1} clash'
        : block.subtitle;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: blocks.length > 1 ? AppColors.danger.withAlpha(60) : block.color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            block.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
              color: AppColors.primaryDark,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 9.5, color: Colors.black87),
          ),
        ],
      ),
    );
  }
}
