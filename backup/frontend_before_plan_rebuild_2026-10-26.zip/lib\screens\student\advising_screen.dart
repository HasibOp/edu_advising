import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/offering.dart';
import '../../providers/advising_provider.dart';
import '../../utils/app_theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/logout_button.dart';
import '../../widgets/notice_banner.dart';
import '../../widgets/offering_card.dart';
import '../../widgets/state_views.dart';
import 'student_async_body.dart';

class AdvisingScreen extends StatefulWidget {
  const AdvisingScreen({super.key, required this.onConfirmed});

  /// Called after advising is saved (the shell switches to My Classes).
  final VoidCallback onConfirmed;

  @override
  State<AdvisingScreen> createState() => _AdvisingScreenState();
}

class _AdvisingScreenState extends State<AdvisingScreen> {
  int? _semester;

  /// The chosen chip, defaulting to the student's own semester.
  int? _activeSemester(AdvisingProvider advising) {
    final semesters = advising.semesters;
    if (semesters.isEmpty) return null;
    final wanted = _semester ?? advising.student?.semester;
    return semesters.contains(wanted) ? wanted : semesters.first;
  }

  void _toggle(AdvisingProvider advising, Offering offering) {
    final error = advising.toggle(offering);
    if (error != null) showAppSnackBar(context, error, isError: true);
  }

  void _selectAll(AdvisingProvider advising, int semester, bool value) {
    final skipped = advising.setAllSelected(semester, value);
    if (skipped > 0) {
      showAppSnackBar(
        context,
        '$skipped course${skipped == 1 ? '' : 's'} skipped: '
        'all sections full or clashing.',
      );
    }
  }

  Future<void> _confirm(AdvisingProvider advising) async {
    final error = await advising.confirmAdvising();
    if (!mounted) return;
    if (error != null) {
      showAppSnackBar(context, error, isError: true);
      return;
    }
    showAppSnackBar(
        context, 'Advising confirmed: ${advising.enrolledOfferings.length} courses.');
    widget.onConfirmed();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Advising'),
        actions: const [LogoutButton()],
      ),
      body: StudentAsyncBody(builder: _buildBody),
      bottomNavigationBar: _buildConfirmBar(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    final advising = context.watch<AdvisingProvider>();
    final semester = _activeSemester(advising);
    final offerings = advising.offeringsFor(semester);
    final blockedReason = advising.advisingBlockedReason;

    return RefreshIndicator(
      onRefresh: advising.refresh,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          ClearanceBanner(student: advising.student!),
          if (advising.isCleared && !advising.windows.regularAdvising) ...[
            const SizedBox(height: 10),
            const WarningBanner(
              title: 'Advising window closed',
              message: 'You can view offerings, but changes are disabled.',
            ),
          ],
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final s in advising.semesters)
                ChoiceChip(
                  label: Text('Sem $s'),
                  selected: s == semester,
                  onSelected: (_) => setState(() => _semester = s),
                ),
            ],
          ),
          const SizedBox(height: 8),
          if (semester != null)
            Row(
              children: [
                Checkbox(
                  value: advising.isAllSelected(semester),
                  onChanged: blockedReason == null
                      ? (v) => _selectAll(advising, semester, v ?? false)
                      : null,
                ),
                const Text('Select all',
                    style: TextStyle(fontWeight: FontWeight.w600)),
                const Spacer(),
                Text(
                  '${advising.selectedCount} selected  •  '
                  '${advising.selectedCredits} cr',
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                ),
              ],
            ),
          const SizedBox(height: 4),
          if (offerings.isEmpty)
            const EmptyState(
              icon: Icons.inbox_outlined,
              title: 'No courses offered for this semester',
            ),
          for (final o in offerings)
            OfferingCard(
              offering: o,
              selected: advising.isSelected(o),
              isEnrolled: advising.isEnrolled(o),
              enabled: blockedReason == null &&
                  (advising.canPick(o) || advising.isSelected(o)),
              onTap: () => _toggle(advising, o),
            ),
        ],
      ),
    );
  }

  Widget? _buildConfirmBar(BuildContext context) {
    final advising = context.watch<AdvisingProvider>();
    if (!advising.hasData) return null;
    final canConfirm = advising.canAdvise && advising.selectedCount > 0;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (advising.hasUnsavedChanges && advising.canAdvise)
            const Padding(
              padding: EdgeInsets.only(bottom: 6),
              child: Text(
                'You have unsaved changes',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
            ),
          CustomButton(
            label: 'Confirm advising',
            icon: Icons.check_circle_outline_rounded,
            expand: true,
            isLoading: advising.isSubmitting,
            onPressed: canConfirm ? () => _confirm(advising) : null,
          ),
        ],
      ),
    );
  }
}
