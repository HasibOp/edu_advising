import 'package:flutter/material.dart';

import '../models/offering.dart';
import '../utils/app_theme.dart';
import '../utils/formatters.dart';
import 'seat_badge.dart';

/// A section card: "CSE 421 Sec A", "Seats 12/40", schedule and seat badge.
class OfferingCard extends StatelessWidget {
  const OfferingCard({
    super.key,
    required this.offering,
    this.selected = false,
    this.enabled = true,
    this.showCheckbox = true,
    this.isEnrolled = false,
    this.onTap,
  });

  final Offering offering;
  final bool selected;
  final bool enabled;
  final bool showCheckbox;
  final bool isEnrolled;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final borderColor = selected ? AppColors.primary : AppColors.border;

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      color: selected ? AppColors.primary.withAlpha(12) : AppColors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: borderColor, width: selected ? 1.6 : 1),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: enabled ? onTap : null,
        child: Opacity(
          opacity: enabled ? 1 : 0.55,
          child: Padding(
            padding: EdgeInsets.fromLTRB(showCheckbox ? 4 : 14, 12, 14, 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (showCheckbox)
                  Checkbox(
                    value: selected,
                    onChanged: enabled ? (_) => onTap?.call() : null,
                  ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        offering.displayName,
                        style: textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        '${offering.courseTitle}  •  ${offering.credits} cr',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: textTheme.bodySmall
                            ?.copyWith(color: AppColors.textMuted),
                      ),
                      const SizedBox(height: 8),
                      _InfoLine(
                        icon: Icons.event_seat_outlined,
                        text: 'Seats ${offering.seatsTaken}/${offering.capacity}',
                      ),
                      _InfoLine(
                        icon: Icons.schedule_rounded,
                        text: Formatters.schedule(offering),
                      ),
                      _InfoLine(
                        icon: Icons.person_outline_rounded,
                        text: offering.facultyName,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    SeatBadge(offering: offering),
                    if (isEnrolled) ...[
                      const SizedBox(height: 6),
                      const Text(
                        'Enrolled',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  const _InfoLine({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 15, color: AppColors.textMuted),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 12.5, color: Colors.black87),
            ),
          ),
        ],
      ),
    );
  }
}
