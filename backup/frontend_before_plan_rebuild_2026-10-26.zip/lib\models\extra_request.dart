enum RequestStatus {
  pending('Pending'),
  approved('Approved'),
  rejected('Rejected'),
  withdrawn('Withdrawn');

  const RequestStatus(this.label);
  final String label;
}

/// A student's request to take a course outside regular advising.
class ExtraRequest {
  const ExtraRequest({
    required this.id,
    required this.studentId,
    required this.courseCode,
    required this.reason,
    required this.status,
    required this.createdAt,
  });

  final String id;
  final String studentId;
  final String courseCode;
  final String reason;
  final RequestStatus status;
  final DateTime createdAt;

  bool get isPending => status == RequestStatus.pending;

  ExtraRequest copyWith({RequestStatus? status}) {
    return ExtraRequest(
      id: id,
      studentId: studentId,
      courseCode: courseCode,
      reason: reason,
      status: status ?? this.status,
      createdAt: createdAt,
    );
  }

  factory ExtraRequest.fromJson(Map<String, dynamic> json) {
    return ExtraRequest(
      id: json['id'] as String,
      studentId: json['studentId'] as String,
      courseCode: json['courseCode'] as String,
      reason: json['reason'] as String,
      status: RequestStatus.values.byName(json['status'] as String),
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'studentId': studentId,
        'courseCode': courseCode,
        'reason': reason,
        'status': status.name,
        'createdAt': createdAt.toIso8601String(),
      };
}
