enum Weekday {
  sat('Sat', 'Saturday'),
  sun('Sun', 'Sunday'),
  mon('Mon', 'Monday'),
  tue('Tue', 'Tuesday'),
  wed('Wed', 'Wednesday'),
  thu('Thu', 'Thursday'),
  fri('Fri', 'Friday');

  const Weekday(this.short, this.full);
  final String short;
  final String full;

  static Weekday fromDate(DateTime date) {
    switch (date.weekday) {
      case DateTime.saturday:
        return Weekday.sat;
      case DateTime.sunday:
        return Weekday.sun;
      case DateTime.monday:
        return Weekday.mon;
      case DateTime.tuesday:
        return Weekday.tue;
      case DateTime.wednesday:
        return Weekday.wed;
      case DateTime.thursday:
        return Weekday.thu;
      default:
        return Weekday.fri;
    }
  }
}

/// One weekly meeting of a section. Times are 24h "HH:mm" strings.
class ClassSchedule {
  const ClassSchedule({
    required this.day,
    required this.startTime,
    required this.endTime,
    required this.room,
  });

  final Weekday day;
  final String startTime;
  final String endTime;
  final String room;

  /// Zero-padded "HH:mm" strings compare correctly as text.
  bool overlaps(ClassSchedule other) =>
      day == other.day &&
      startTime.compareTo(other.endTime) < 0 &&
      other.startTime.compareTo(endTime) < 0;

  factory ClassSchedule.fromJson(Map<String, dynamic> json) {
    return ClassSchedule(
      day: Weekday.values.byName(json['day'] as String),
      startTime: json['startTime'] as String,
      endTime: json['endTime'] as String,
      room: json['room'] as String,
    );
  }

  Map<String, dynamic> toJson() => {
        'day': day.name,
        'startTime': startTime,
        'endTime': endTime,
        'room': room,
      };
}
