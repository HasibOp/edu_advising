import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/advising_provider.dart';
import '../../providers/auth_provider.dart';
import '../../utils/app_theme.dart';
import 'advising_screen.dart';
import 'extra_course_screen.dart';
import 'my_classes_screen.dart';
import 'offer_list_screen.dart';
import 'routine_screen.dart';

enum StudentTab { advising, myClasses, routine, offerList, extraCourse }

/// Bottom-navigation container for all student screens.
class StudentShell extends StatefulWidget {
  const StudentShell({super.key, this.initialTab = StudentTab.advising});

  final StudentTab initialTab;

  @override
  State<StudentShell> createState() => _StudentShellState();
}

class _StudentShellState extends State<StudentShell> {
  late int _index = widget.initialTab.index;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = context.read<AuthProvider>().currentUser;
      if (user != null) context.read<AdvisingProvider>().load(user);
    });
  }

  void _goTo(StudentTab tab) => setState(() => _index = tab.index);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          AdvisingScreen(onConfirmed: () => _goTo(StudentTab.myClasses)),
          MyClassesScreen(onStartAdvising: () => _goTo(StudentTab.advising)),
          const RoutineScreen(),
          const OfferListScreen(),
          const ExtraCourseScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        backgroundColor: Colors.white,
        indicatorColor: AppColors.primary.withAlpha(35),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.fact_check_outlined),
            selectedIcon: Icon(Icons.fact_check, color: AppColors.primary),
            label: 'Advising',
          ),
          NavigationDestination(
            icon: Icon(Icons.class_outlined),
            selectedIcon: Icon(Icons.class_, color: AppColors.primary),
            label: 'Classes',
          ),
          NavigationDestination(
            icon: Icon(Icons.calendar_month_outlined),
            selectedIcon: Icon(Icons.calendar_month, color: AppColors.primary),
            label: 'Routine',
          ),
          NavigationDestination(
            icon: Icon(Icons.list_alt_outlined),
            selectedIcon: Icon(Icons.list_alt, color: AppColors.primary),
            label: 'Offers',
          ),
          NavigationDestination(
            icon: Icon(Icons.add_task_outlined),
            selectedIcon: Icon(Icons.add_task, color: AppColors.primary),
            label: 'Extra',
          ),
        ],
      ),
    );
  }
}
