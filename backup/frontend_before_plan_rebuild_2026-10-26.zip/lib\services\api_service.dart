import '../models/advising_windows.dart';
import '../models/enrolment.dart';
import '../models/exam_schedule.dart';
import '../models/extra_request.dart';
import '../models/offering.dart';
import '../models/user.dart';

/// Thrown by an [ApiService] with a message that is safe to show to the user.
class ApiException implements Exception {
  const ApiException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// Everything the UI needs from the backend.
///
/// The app currently runs on [MockApiService]. When the backend is ready,
/// add an HTTP implementation of this class and pass it to `EduAdvisingApp`
/// in `main.dart`; providers and screens do not need to change.
abstract class ApiService {
  Future<User> login(String loginId, String password);

  // Offerings & enrolment
  Future<List<Offering>> fetchOfferings();
  Future<List<Enrolment>> fetchEnrolments(String studentId);

  /// Replaces the student's enrolments with [offeringIds] and returns the
  /// resulting active enrolments.
  Future<List<Enrolment>> saveAdvising(String studentId, List<String> offeringIds);
  Future<Enrolment> addEnrolment(String studentId, String offeringId);
  Future<void> dropEnrolment(String enrolmentId);
  Future<List<ExamSchedule>> fetchExams();

  // Extra course requests
  Future<List<ExtraRequest>> fetchExtraRequests(String studentId);
  Future<ExtraRequest> createExtraRequest(
      String studentId, String courseCode, String reason);
  Future<ExtraRequest> updateExtraRequestStatus(
      String requestId, RequestStatus status);

  // Students & clearance
  Future<User?> findStudent(String studentId);
  Future<List<User>> fetchStudents();
  Future<User> setClearance(String studentId, ClearanceStatus status);

  // Advising windows
  Future<AdvisingWindows> fetchWindows();
  Future<AdvisingWindows> updateWindows(AdvisingWindows windows);
}
