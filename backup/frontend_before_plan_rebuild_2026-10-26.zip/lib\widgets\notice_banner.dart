import 'package:flutter/material.dart';

import '../models/user.dart';
import '../utils/app_theme.dart';

/// A coloured banner with an icon, a title and an optional message.
class NoticeBanner extends StatelessWidget {
  const NoticeBanner({
    super.key,
    required this.icon,
    required this.title,
    required this.color,
    this.message,
    this.textColor = Colors.white,
    this.trailing,
  });

  final IconData icon;
  final String title;
  final String? message;
  final Color color;
  final Color textColor;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(icon, color: textColor, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: textColor,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
                if (message != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    message!,
                    style: TextStyle(color: textColor.withAlpha(230), fontSize: 12.5),
                  ),
                ],
              ],
            ),
          ),
          if (trailing != null) ...[const SizedBox(width: 8), trailing!],
        ],
      ),
    );
  }
}

/// Green when the student is cleared for advising, red when not.
class ClearanceBanner extends StatelessWidget {
  const ClearanceBanner({super.key, required this.student, this.trailing});

  final User student;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final cleared = student.isCleared;
    return NoticeBanner(
      icon: cleared ? Icons.verified_rounded : Icons.block_rounded,
      color: cleared ? AppColors.success : AppColors.danger,
      title: cleared ? 'Cleared for advising' : 'Not cleared for advising',
      message:
          '${student.name}  •  ${student.studentId}  •  Semester ${student.semester}',
      trailing: trailing,
    );
  }
}

/// Gold banner for closed windows and other cautions.
class WarningBanner extends StatelessWidget {
  const WarningBanner({super.key, required this.title, this.message});

  final String title;
  final String? message;

  @override
  Widget build(BuildContext context) {
    return NoticeBanner(
      icon: Icons.info_outline_rounded,
      color: AppColors.warning,
      textColor: AppColors.onWarning,
      title: title,
      message: message,
    );
  }
}
