import 'schedule.dart';

enum SeatStatus { open, low, full }

/// A section of a course offered this term.
class Offering {
  const Offering({
    required this.id,
    required this.courseCode,
    required this.courseTitle,
    required this.section,
    required this.semester,
    required this.credits,
    required this.capacity,
    required this.seatsTaken,
    required this.facultyId,
    required this.facultyName,
    this.schedule = const [],
  });

  /// At or below this many free seats a section is shown as "X left".
  static const int lowSeatThreshold = 5;

  final String id;
  final String courseCode;
  final String courseTitle;
  final String section;
  final int semester;
  final int credits;
  final int capacity;
  final int seatsTaken;
  final String facultyId;
  final String facultyName;
  final List<ClassSchedule> schedule;

  int get seatsLeft => seatsTaken >= capacity ? 0 : capacity - seatsTaken;
  bool get isFull => seatsTaken >= capacity;

  SeatStatus get seatStatus {
    if (isFull) return SeatStatus.full;
    if (seatsLeft <= lowSeatThreshold) return SeatStatus.low;
    return SeatStatus.open;
  }

  /// e.g. "CSE 421 Sec A"
  String get displayName => '$courseCode Sec $section';

  bool clashesWith(Offering other) =>
      id != other.id &&
      schedule.any((mine) => other.schedule.any(mine.overlaps));

  Offering copyWith({int? seatsTaken}) {
    return Offering(
      id: id,
      courseCode: courseCode,
      courseTitle: courseTitle,
      section: section,
      semester: semester,
      credits: credits,
      capacity: capacity,
      seatsTaken: seatsTaken ?? this.seatsTaken,
      facultyId: facultyId,
      facultyName: facultyName,
      schedule: schedule,
    );
  }

  factory Offering.fromJson(Map<String, dynamic> json) {
    return Offering(
      id: json['id'] as String,
      courseCode: json['courseCode'] as String,
      courseTitle: json['courseTitle'] as String,
      section: json['section'] as String,
      semester: json['semester'] as int,
      credits: json['credits'] as int,
      capacity: json['capacity'] as int,
      seatsTaken: json['seatsTaken'] as int,
      facultyId: json['facultyId'] as String,
      facultyName: json['facultyName'] as String,
      schedule: (json['schedule'] as List<dynamic>? ?? [])
          .map((e) => ClassSchedule.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'courseCode': courseCode,
        'courseTitle': courseTitle,
        'section': section,
        'semester': semester,
        'credits': credits,
        'capacity': capacity,
        'seatsTaken': seatsTaken,
        'facultyId': facultyId,
        'facultyName': facultyName,
        'schedule': schedule.map((s) => s.toJson()).toList(),
      };
}
