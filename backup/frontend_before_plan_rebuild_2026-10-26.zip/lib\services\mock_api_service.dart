import '../data/mock_data.dart';
import '../models/advising_windows.dart';
import '../models/enrolment.dart';
import '../models/exam_schedule.dart';
import '../models/extra_request.dart';
import '../models/offering.dart';
import '../models/user.dart';
import 'api_service.dart';

/// In-memory backend. State lives for the app session, so changes made in
/// one role (e.g. admin revoking clearance) show up after logging in as
/// another role.
class MockApiService implements ApiService {
  MockApiService({this.latency = const Duration(milliseconds: 350)})
      : _users = {for (final u in MockData.users) u.studentId: u},
        _offerings = {for (final o in MockData.offerings) o.id: o},
        _enrolments = List.of(MockData.enrolments),
        _requests = List.of(MockData.extraRequests),
        _windows = MockData.windows;

  /// Simulated network delay. Use [Duration.zero] in tests.
  final Duration latency;

  final Map<String, User> _users;
  final Map<String, Offering> _offerings;
  final List<Enrolment> _enrolments;
  final List<ExtraRequest> _requests;
  AdvisingWindows _windows;
  int _seq = 1000;

  String _nextId(String prefix) => '$prefix-${_seq++}';
  Future<void> _delay() => Future<void>.delayed(latency);

  Offering _offering(String id) {
    final offering = _offerings[id];
    if (offering == null) throw const ApiException('Course section not found.');
    return offering;
  }

  List<Enrolment> _activeFor(String studentId) => _enrolments
      .where((e) => e.studentId == studentId && e.isActive)
      .toList();

  void _replaceEnrolment(Enrolment updated) {
    final index = _enrolments.indexWhere((e) => e.id == updated.id);
    _enrolments[index] = updated;
  }

  void _changeSeats(String offeringId, int delta) {
    final o = _offering(offeringId);
    _offerings[offeringId] = o.copyWith(seatsTaken: o.seatsTaken + delta);
  }

  /// Rejects a set of sections that repeats a course or has a time clash.
  void _validateCombination(List<Offering> offerings) {
    for (var i = 0; i < offerings.length; i++) {
      for (var j = i + 1; j < offerings.length; j++) {
        final a = offerings[i];
        final b = offerings[j];
        if (a.courseCode == b.courseCode) {
          throw ApiException('You can take only one section of ${a.courseCode}.');
        }
        if (a.clashesWith(b)) {
          throw ApiException(
              '${a.displayName} clashes with ${b.displayName}.');
        }
      }
    }
  }

  @override
  Future<User> login(String loginId, String password) async {
    await _delay();
    final id = loginId.trim();
    if (id.isEmpty || password.isEmpty) {
      throw const ApiException('Enter your ID and password.');
    }
    final lower = id.toLowerCase();
    if (lower == 'admin' || lower == 'instructor') return _users[lower]!;

    // Any other ID signs in as a student; unknown IDs get a fresh profile.
    return _users.putIfAbsent(
      id,
      () => User(
        id: _nextId('u'),
        role: UserRole.student,
        studentId: id,
        name: 'Student $id',
        semester: 10,
        clearanceStatus: ClearanceStatus.cleared,
      ),
    );
  }

  @override
  Future<List<Offering>> fetchOfferings() async {
    await _delay();
    return _offerings.values.toList();
  }

  @override
  Future<List<Enrolment>> fetchEnrolments(String studentId) async {
    await _delay();
    return _activeFor(studentId);
  }

  @override
  Future<List<Enrolment>> saveAdvising(
      String studentId, List<String> offeringIds) async {
    await _delay();
    final student = _users[studentId];
    if (student == null) throw const ApiException('Student not found.');
    if (!student.isCleared) {
      throw const ApiException('You are not cleared for advising.');
    }
    if (!_windows.regularAdvising) {
      throw const ApiException('The regular advising window is closed.');
    }

    final current = _activeFor(studentId);
    final currentIds = current.map((e) => e.offeringId).toSet();
    final wanted = offeringIds.toSet();
    final added = wanted.difference(currentIds);

    for (final id in added) {
      final o = _offering(id);
      if (o.isFull) {
        throw ApiException('${o.displayName} just filled up. Pick another section.');
      }
    }
    _validateCombination(wanted.map(_offering).toList());

    for (final e in current.where((e) => !wanted.contains(e.offeringId))) {
      _replaceEnrolment(e.copyWith(status: EnrolmentStatus.dropped));
      _changeSeats(e.offeringId, -1);
    }
    for (final id in added) {
      _enrolments.add(Enrolment(
        id: _nextId('enr'),
        studentId: studentId,
        offeringId: id,
        status: EnrolmentStatus.enrolled,
        createdAt: DateTime.now(),
      ));
      _changeSeats(id, 1);
    }
    return _activeFor(studentId);
  }

  @override
  Future<Enrolment> addEnrolment(String studentId, String offeringId) async {
    await _delay();
    if (_users[studentId] == null) throw const ApiException('Student not found.');
    final o = _offering(offeringId);
    if (o.isFull) throw ApiException('${o.displayName} is full.');

    final current =
        _activeFor(studentId).map((e) => _offering(e.offeringId)).toList();
    _validateCombination([...current, o]);

    final enrolment = Enrolment(
      id: _nextId('enr'),
      studentId: studentId,
      offeringId: offeringId,
      status: EnrolmentStatus.enrolled,
      createdAt: DateTime.now(),
    );
    _enrolments.add(enrolment);
    _changeSeats(offeringId, 1);
    return enrolment;
  }

  @override
  Future<void> dropEnrolment(String enrolmentId) async {
    await _delay();
    final index = _enrolments.indexWhere((e) => e.id == enrolmentId);
    if (index == -1 || !_enrolments[index].isActive) {
      throw const ApiException('Enrolment not found.');
    }
    final e = _enrolments[index];
    _enrolments[index] = e.copyWith(status: EnrolmentStatus.dropped);
    _changeSeats(e.offeringId, -1);
  }

  @override
  Future<List<ExamSchedule>> fetchExams() async {
    await _delay();
    return List.of(MockData.exams);
  }

  @override
  Future<List<ExtraRequest>> fetchExtraRequests(String studentId) async {
    await _delay();
    return _requests.where((r) => r.studentId == studentId).toList();
  }

  @override
  Future<ExtraRequest> createExtraRequest(
      String studentId, String courseCode, String reason) async {
    await _delay();
    if (!_windows.extraCourse) {
      throw const ApiException('The extra course window is closed.');
    }
    final duplicate = _requests.any((r) =>
        r.studentId == studentId && r.courseCode == courseCode && r.isPending);
    if (duplicate) {
      throw ApiException('You already have a pending request for $courseCode.');
    }
    final request = ExtraRequest(
      id: _nextId('req'),
      studentId: studentId,
      courseCode: courseCode,
      reason: reason,
      status: RequestStatus.pending,
      createdAt: DateTime.now(),
    );
    _requests.add(request);
    return request;
  }

  @override
  Future<ExtraRequest> updateExtraRequestStatus(
      String requestId, RequestStatus status) async {
    await _delay();
    final index = _requests.indexWhere((r) => r.id == requestId);
    if (index == -1) throw const ApiException('Request not found.');
    if (!_requests[index].isPending) {
      throw const ApiException('This request has already been closed.');
    }
    final updated = _requests[index].copyWith(status: status);
    _requests[index] = updated;
    return updated;
  }

  @override
  Future<User?> findStudent(String studentId) async {
    await _delay();
    final user = _users[studentId.trim()];
    return user?.role == UserRole.student ? user : null;
  }

  @override
  Future<List<User>> fetchStudents() async {
    await _delay();
    return _users.values.where((u) => u.role == UserRole.student).toList()
      ..sort((a, b) => a.studentId.compareTo(b.studentId));
  }

  @override
  Future<User> setClearance(String studentId, ClearanceStatus status) async {
    await _delay();
    final user = _users[studentId];
    if (user == null) throw const ApiException('Student not found.');
    final updated = user.copyWith(clearanceStatus: status);
    _users[studentId] = updated;
    return updated;
  }

  @override
  Future<AdvisingWindows> fetchWindows() async {
    await _delay();
    return _windows;
  }

  @override
  Future<AdvisingWindows> updateWindows(AdvisingWindows windows) async {
    await _delay();
    _windows = windows;
    return _windows;
  }
}
